#include <iostream>
using namespace std;

// TODO: 포인터 2개, 허용 차이, 참조변수 1개를 받는 equalArray 함수 전체를 작성하세요.
// Write the entire equalArray function with two pointers, a tolerance, and one reference parameter.

int main() {
    int a[5], b[5];
    int tolerance;
    int differentCount = 0;
    bool same;

    cout << "첫 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << "두 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> b[i];
    cout << "허용 차이를 입력하세요:" << '\n';
    cin >> tolerance;

    same = equalArray(a, b, tolerance, differentCount);
    cout << (same ? "SAME" : "DIFFERENT") << '\n';
    cout << differentCount << '\n';

    return 0;
}
