// 정답 / Answer: 1. 허용 차이로 두 배열 비교
// Compare Two Arrays Within a Tolerance
// 풀이: 같은 순서의 숫자를 비교해 허용 차이 초과 개수를 집계합니다.
// Solution: Compare corresponding elements and count differences exceeding the tolerance.

#include <iostream>
using namespace std;

bool equalArray(int* p, int* q, int tolerance, int& differentCount) {
    differentCount = 0;
    for (int i = 0; i < 5; ++i) {
        int difference = *(p + i) - *(q + i);
        if (difference < 0) difference = -difference;
        if (difference > tolerance) ++differentCount;
    }
    return differentCount == 0;
}

int main() {
    int a[5], b[5];
    int tolerance;
    int differentCount = 0;
    bool same;

    cout << "첫 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << "두 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> b[i];
    cout << "허용 차이를 입력하세요:" << '\n';
    cin >> tolerance;

    same = equalArray(a, b, tolerance, differentCount);
    cout << (same ? "SAME" : "DIFFERENT") << '\n';
    cout << differentCount << '\n';

    return 0;
}
