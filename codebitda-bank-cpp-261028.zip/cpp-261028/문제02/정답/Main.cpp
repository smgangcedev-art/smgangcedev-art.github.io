// 정답 / Answer: 2. 상한을 적용한 최저 점수 보충과 팀 점수 계산
// Supplement the Lowest Score with a Cap and Calculate the Team Score
// 풀이: 첫 최솟값을 참조로 보정한 뒤 제공된 점수 계산 함수를 호출합니다.
// Solution: Adjust the first minimum through a reference, then call the provided scoring functions.

#include <iostream>
using namespace std;

int& findMin(int* p, int size) {
    int* best = p;
    for (int i = 1; i < size; ++i)
        if (*(p + i) < *best) best = p + i;
    return *best;
}

void supplementScore(int& score, int amount, int limit) {
    score += amount;
    if (score > limit) score = limit;
}

int calculateScore(int score, int bonus = 10) {
    return score + bonus;
}

int calculateScore(int* p, int size) {
    int total = 0;
    int lowest = *p;
    for (int i = 0; i < size; ++i) {
        int score = *(p + i);
        total += score;
        if (score < lowest) lowest = score;
    }
    return total - lowest;
}

int main() {
    int personal, team[4], supplement, limit;
    int personalResult = 0, teamResult = 0;

    cout << "개인 점수를 입력하세요:" << '\n';
    cin >> personal;
    cout << "팀원 4명의 점수를 입력하세요:" << '\n';
    for (int i = 0; i < 4; ++i) cin >> team[i];

    cout << "보충 점수와 상한 점수를 입력하세요:" << '\n';
    cin >> supplement >> limit;

    supplementScore(findMin(team, 4), supplement, limit);
    personalResult = calculateScore(personal);
    teamResult = calculateScore(team, 4);

    cout << personalResult << '\n';
    cout << teamResult << '\n';

    return 0;
}
