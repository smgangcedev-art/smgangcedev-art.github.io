#include <iostream>
using namespace std;

// TODO: 첫 최솟값 원소를 참조로 반환하는 findMin 함수 전체를 작성하세요.
// Write the entire findMin function returning a reference to the first minimum element.

// TODO: 참조로 받은 점수에 보충 점수를 더하고 상한을 적용하는 함수 전체를 작성하세요.
// Write the entire function to add the supplement and cap the referenced score.

int calculateScore(int score, int bonus = 10) {
    return score + bonus;
}

int calculateScore(int* p, int size) {
    int total = 0;
    int lowest = *p;
    for (int i = 0; i < size; ++i) {
        int score = *(p + i);
        total += score;
        if (score < lowest) lowest = score;
    }
    return total - lowest;
}

int main() {
    int personal, team[4], supplement, limit;
    int personalResult = 0, teamResult = 0;

    cout << "개인 점수를 입력하세요:" << '\n';
    cin >> personal;
    cout << "팀원 4명의 점수를 입력하세요:" << '\n';
    for (int i = 0; i < 4; ++i) cin >> team[i];

    cout << "보충 점수와 상한 점수를 입력하세요:" << '\n';
    cin >> supplement >> limit;

    // TODO: 참조 리턴을 보충 함수에 전달하여 첫 최솟값을 보정하세요.
    // Pass the returned reference to the supplement function to adjust the first minimum.

    // TODO: 개인은 기본 보너스, 팀은 보정된 배열로 계산 함수를 호출하세요.
    // Call the personal overload with its default bonus and the team overload with the adjusted array.

    cout << personalResult << '\n';
    cout << teamResult << '\n';

    return 0;
}
