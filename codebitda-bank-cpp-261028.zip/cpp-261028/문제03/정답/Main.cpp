// 정답 / Answer: 3. 예산 안에서 가장 비싼 책 선택
// Select the Most Expensive Book Within a Budget
// 풀이: 예산 이하의 최고 가격 책을 선택하며 동점이면 첫 책을 유지합니다.
// Solution: Select the most expensive affordable book, retaining the first one on ties.

#include <iostream>
using namespace std;

#include <string>

class Book {
private:
    string title;
    int price;
public:
    Book();
    ~Book();
    Book(string title, int price);
    string getTitle();
    int getPrice();
};
Book::Book() : Book("", 0) {}
Book::Book(string title, int price) : title(title), price(price) {
    cout << "생성했습니다." << '\n';
}
string Book::getTitle() { return title; }
int Book::getPrice() { return price; }
int findBook(Book* p, int size, int budget) {
    int selected = -1;
    for (int i = 0; i < size; ++i) {
        Book* current = p + i;
        if (current->getPrice() <= budget) {
            if (selected == -1 || current->getPrice() > (p + selected)->getPrice())
                selected = i;
        }
    }
    return selected;
}

Book::~Book() {
    cout << "소멸했습니다." << '\n';
}
int main() {
    string titles[3] = {"A", "B", "C"};
    int prices[3], budget;
    int selected;

    cout << "A, B, C 책의 가격 3개를 입력하세요:" << '\n';
    for (int i = 0; i < 3; ++i) cin >> prices[i];
    cout << "구매 예산을 입력하세요:" << '\n';
    cin >> budget;

    Book books[3] = {Book(titles[0], prices[0]), Book(titles[1], prices[1]), Book(titles[2], prices[2])};
    selected = findBook(books, 3, budget);
    if (selected == -1) {
        cout << "NONE" << '\n';
    } else {
        cout << (books + selected)->getTitle() << '\n';
        cout << (books + selected)->getPrice() << '\n';
        cout << budget - (books + selected)->getPrice() << '\n';
    }

    return 0;
}
