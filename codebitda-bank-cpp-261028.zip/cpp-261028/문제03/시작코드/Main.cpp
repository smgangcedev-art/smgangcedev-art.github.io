#include <iostream>
using namespace std;

#include <string>

class Book {
private:
    string title;
    int price;
public:
    Book();
    ~Book();
    Book(string title, int price);
    string getTitle();
    int getPrice();
};
Book::Book() : Book("", 0) {}
Book::Book(string title, int price) : title(title), price(price) {
    cout << "생성했습니다." << '\n';
}
string Book::getTitle() { return title; }
int Book::getPrice() { return price; }

// TODO: 예산 이하에서 가장 비싼 책의 위치를 반환하는 findBook 함수 전체를 작성하세요.
// Write the entire findBook function returning the index of the most expensive affordable book, or -1.

Book::~Book() {
    cout << "소멸했습니다." << '\n';
}
int main() {
    string titles[3] = {"A", "B", "C"};
    int prices[3], budget;
    int selected;

    cout << "A, B, C 책의 가격 3개를 입력하세요:" << '\n';
    for (int i = 0; i < 3; ++i) cin >> prices[i];
    cout << "구매 예산을 입력하세요:" << '\n';
    cin >> budget;

    Book books[3] = {Book(titles[0], prices[0]), Book(titles[1], prices[1]), Book(titles[2], prices[2])};
    selected = findBook(books, 3, budget);
    if (selected == -1) {
        cout << "NONE" << '\n';
    } else {
        cout << (books + selected)->getTitle() << '\n';
        cout << (books + selected)->getPrice() << '\n';
        cout << budget - (books + selected)->getPrice() << '\n';
    }

    return 0;
}
