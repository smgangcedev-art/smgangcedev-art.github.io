// 정답 / Answer: 5. 카페 선불카드와 텀블러 할인
// Cafe Prepaid Cards and Tumbler Discounts
// 풀이: 카드별 잔액을 관리하고 두 결제 오버로딩과 동적 배열을 사용합니다.
// Solution: Maintain each card balance using two payment overloads and a dynamic object array.

#include <iostream>
using namespace std;

class CafeCard {
private:
    int balance;
public:
    CafeCard() {
        balance = 0;
        cout << "생성했습니다." << '\n';
    }
    ~CafeCard() {
        cout << "소멸했습니다." << '\n';
    }
    void charge(int amount) { balance += amount; }
    bool pay(int price) {
        if (balance < price) return false;
        balance -= price;
        return true;
    }
    bool pay(int price, int discount) {
        int cost = price - discount;
        if (cost < 0) cost = 0;
        return pay(cost);
    }
    int getBalance() { return balance; }
};

int main() {
    int n;
    CafeCard* cards;

    cout << "카드 개수를 입력하세요 (1~10):" << '\n';
    cin >> n;

    cards = new CafeCard[n];

    for (int i = 0; i < n; ++i) {
        int amount, regularPrice, tumblerPrice, discount;
        bool regularSuccess, tumblerSuccess;

        cout << i + 1 << "번 카드의 충전액, 일반 음료 가격, 텀블러 음료 가격, 할인액을 입력하세요:" << '\n';
        cin >> amount >> regularPrice >> tumblerPrice >> discount;

        cards[i].charge(amount);
        regularSuccess = cards[i].pay(regularPrice);
        cout << "일반 결제: " << (regularSuccess ? "SUCCESS" : "FAIL") << '\n';
        cout << "잔액: " << cards[i].getBalance() << '\n';

        tumblerSuccess = cards[i].pay(tumblerPrice, discount);
        cout << "텀블러 결제: " << (tumblerSuccess ? "SUCCESS" : "FAIL") << '\n';
        cout << "잔액: " << cards[i].getBalance() << '\n';
    }

    delete[] cards;

    return 0;
}
