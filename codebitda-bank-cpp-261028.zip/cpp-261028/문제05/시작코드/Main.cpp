#include <iostream>
using namespace std;

// TODO: CafeCard 클래스 전체를 작성하세요. private 잔액과 public 생성자·소멸자·충전·결제 오버로딩·잔액 조회 함수를 포함하세요.
// Write the entire CafeCard class with a private balance and public constructor, destructor, charge, pay overloads, and balance getter.

int main() {
    int n;
    CafeCard* cards;

    cout << "카드 개수를 입력하세요 (1~10):" << '\n';
    cin >> n;

    // TODO: 입력한 개수만큼 CafeCard 객체 배열을 동적으로 생성하세요.
    // Dynamically allocate an array of n CafeCard objects.

    for (int i = 0; i < n; ++i) {
        int amount, regularPrice, tumblerPrice, discount;
        bool regularSuccess, tumblerSuccess;

        cout << i + 1 << "번 카드의 충전액, 일반 음료 가격, 텀블러 음료 가격, 할인액을 입력하세요:" << '\n';
        cin >> amount >> regularPrice >> tumblerPrice >> discount;

        // TODO: 충전 후 일반 결제를 호출하고 결과를 regularSuccess에 저장하세요.
        // Charge the card, call regular payment, and store its result in regularSuccess.

        cout << "일반 결제: " << (regularSuccess ? "SUCCESS" : "FAIL") << '\n';
        cout << "잔액: " << cards[i].getBalance() << '\n';

        // TODO: 할인 결제 오버로딩을 호출하고 결과를 tumblerSuccess에 저장하세요.
        // Call the discounted payment overload and store its result in tumblerSuccess.

        cout << "텀블러 결제: " << (tumblerSuccess ? "SUCCESS" : "FAIL") << '\n';
        cout << "잔액: " << cards[i].getBalance() << '\n';
    }

    // TODO: 동적으로 생성한 객체 배열을 해제하세요.
    // Release the dynamically allocated object array.

    return 0;
}
