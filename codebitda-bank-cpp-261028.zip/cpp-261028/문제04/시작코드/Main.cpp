#include <iostream>
using namespace std;

class GameSave {
private:
    int* gold;
public:
    GameSave();
    GameSave(int amount);
    GameSave(GameSave& other);
    ~GameSave();
    bool transferTo(GameSave& target, int amount);
    void setGold(int amount) { *gold = amount; }
    int getGold() { return *gold; }
    void buyItem(int price) { *gold -= price; }
};

GameSave::GameSave() : GameSave(0) {}

GameSave::GameSave(int amount) {
    gold = new int(amount);
    cout << "생성했습니다." << '\n';
}

GameSave::GameSave(GameSave& other) {
    gold = new int(*other.gold);
    cout << "생성했습니다." << '\n';
}

GameSave::~GameSave() {
    delete gold;
    cout << "소멸했습니다." << '\n';
}

// TODO: 객체 참조로 골드를 이전하는 transferTo의 전체 정의를 클래스 밖에 작성하세요.
// Define the entire transferTo method outside the class using an object reference.

int main() {
    int amount, price1, price2, send1, send2;
    GameSave* playing1;
    GameSave* playing2;
    bool success1, success2;

    cout << "저장 골드와 플레이 1·2의 아이템 가격을 입력하세요:" << '\n';
    cin >> amount >> price1 >> price2;
    cout << "플레이 1에서 2로, 2에서 1로 보낼 골드를 입력하세요:" << '\n';
    cin >> send1 >> send2;

    cout << "[저장 슬롯 불러오기]" << '\n';
    GameSave original(amount);
    cout << "저장된 골드: " << original.getGold() << '\n';

    cout << "[두 개의 플레이 시작]" << '\n';
    playing1 = new GameSave(original);
    playing2 = new GameSave(original);
    playing1->buyItem(price1);
    playing2->buyItem(price2);
    cout << "[아이템 구매 후]" << '\n';
    cout << "플레이 1 골드: " << playing1->getGold() << '\n';
    cout << "플레이 2 골드: " << playing2->getGold() << '\n';

    cout << "[플레이 1 -> 플레이 2]" << '\n';

    // TODO: 플레이 1에서 플레이 2로 이전하고 반환값을 success1에 저장하세요.
    // Transfer from play 1 to play 2 and store the result in success1.

    cout << (success1 ? "SUCCESS" : "FAIL") << '\n';
    cout << "플레이 1 골드: " << playing1->getGold() << '\n';
    cout << "플레이 2 골드: " << playing2->getGold() << '\n';

    cout << "[플레이 2 -> 플레이 1]" << '\n';

    // TODO: 플레이 2에서 플레이 1로 이전하고 반환값을 success2에 저장하세요.
    // Transfer from play 2 to play 1 and store the result in success2.

    cout << (success2 ? "SUCCESS" : "FAIL") << '\n';
    cout << "플레이 1 골드: " << playing1->getGold() << '\n';
    cout << "플레이 2 골드: " << playing2->getGold() << '\n';
    cout << "원본 골드: " << original.getGold() << '\n';

    cout << "[플레이 종료]" << '\n';
    delete playing1;
    delete playing2;
    cout << "[저장 슬롯 다시 확인]" << '\n';
    cout << "저장된 골드: " << original.getGold() << '\n';
    cout << "[게임 종료]" << '\n';

    return 0;
}
