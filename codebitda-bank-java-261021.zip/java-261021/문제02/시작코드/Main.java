import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum = 0;
        // 입력 순서는 1부터 셉니다.
        // Count input positions from 1.
        for (int position = 1; position <= n; position++) {
            int value = sc.nextInt();
            // TODO 1: 필요한 입력 순서의 값만 합계에 더하세요.
            // TODO 1: Add only the values at the required input positions.
        }
        System.out.println("sum: " + sum);
        sc.close();
    }
}
