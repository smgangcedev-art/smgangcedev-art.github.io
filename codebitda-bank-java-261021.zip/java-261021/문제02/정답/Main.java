import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int sum = 0;
        // 입력 순서는 1부터 셉니다.
        // Count input positions from 1.
        for (int position = 1; position <= n; position++) {
            int value = sc.nextInt();
            // 값이 아니라 입력 위치가 짝수인지 확인합니다.
            // Check whether the position, not the value, is even.
            if (position % 2 == 0) {
                sum += value;
            }
        }
        System.out.println("sum: " + sum);
        sc.close();
    }
}
