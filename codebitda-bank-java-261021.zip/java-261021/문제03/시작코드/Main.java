import java.util.Scanner;

class Wallet {
    private int balance;
    public Wallet(int balance) { this.balance = balance; }
    public int getBalance() { return balance; }
    public void deposit(int amount) { balance += amount; }
    public boolean withdraw(int amount) {
        if (balance < amount) return false;
        balance -= amount;
        return true;
    }
    public int shareWith(Wallet other) {
        // TODO 1: 문제의 규칙에 따라 두 지갑의 잔액을 나누세요.
        // TODO 1: Share the two balances according to the problem rules.
        // 아래 예외 문장은 구현할 때 제거하세요.
        // Remove the exception below when implementing this method.
        throw new UnsupportedOperationException("TODO: shareWith");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Wallet a = new Wallet(sc.nextInt());
        Wallet b = new Wallet(sc.nextInt());
        int moved = a.shareWith(b);
        if (moved == -1) System.out.println("impossible");
        else System.out.println("moved: " + moved);
        System.out.println("balance: " + a.getBalance() + " " + b.getBalance());
        sc.close();
    }
}
