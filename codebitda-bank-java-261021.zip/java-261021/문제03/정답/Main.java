import java.util.Scanner;

class Wallet {
    private int balance;
    public Wallet(int balance) { this.balance = balance; }
    public int getBalance() { return balance; }
    public void deposit(int amount) { balance += amount; }
    public boolean withdraw(int amount) {
        if (balance < amount) return false;
        balance -= amount;
        return true;
    }
    public int shareWith(Wallet other) {
        // 나눌 수 있는지 먼저 확인하여 실패 시 두 잔액을 보존합니다.
        // Check divisibility first to preserve both balances on failure.
        if ((balance + other.getBalance()) % 2 != 0) return -1;
        if (balance == other.getBalance()) return 0;
        // 많은 지갑에서 차액의 절반만 옮깁니다.
        // Move half the difference from the richer wallet.
        int amount;
        if (balance > other.getBalance()) {
            amount = (balance - other.getBalance()) / 2;
            withdraw(amount);
            other.deposit(amount);
        } else {
            amount = (other.getBalance() - balance) / 2;
            other.withdraw(amount);
            deposit(amount);
        }
        return amount;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Wallet a = new Wallet(sc.nextInt());
        Wallet b = new Wallet(sc.nextInt());
        int moved = a.shareWith(b);
        if (moved == -1) System.out.println("impossible");
        else System.out.println("moved: " + moved);
        System.out.println("balance: " + a.getBalance() + " " + b.getBalance());
        sc.close();
    }
}
