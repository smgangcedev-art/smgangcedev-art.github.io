import java.util.Scanner;

abstract class Shipment {
    protected int weight;
    Shipment(int weight) { this.weight = weight; }
    public abstract int fee();
}
interface Trackable { String track(); }
class Regular extends Shipment {
    Regular(int weight) { super(weight); }
    @Override public int fee() { return weight * 100; }
}
class Express extends Shipment implements Trackable {
    Express(int weight) { super(weight); }
    @Override public int fee() { return weight * 200 + 500; }
    @Override public String track() { return "EXPRESS"; }
}
class Desk {
    public void show(Shipment s) { System.out.println("shipment: " + s.fee()); }
    public void show(Express e) { System.out.println("express: " + e.fee()); }
}
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int type = sc.nextInt(), weight = sc.nextInt();
        Shipment s;
        if (type == 1) s = new Regular(weight);
        else s = new Express(weight);
        Desk desk = new Desk();
        // show는 선언 타입, fee는 실제 객체 타입에 따라 선택됩니다.
        // show uses the declared type; fee dispatches to the actual object.
        desk.show(s);
        if (s instanceof Express) {
            Express e = (Express) s;
            desk.show(e);
            Trackable t = e;
            System.out.println(t.track());
        } else {
            System.out.println("no tracking");
        }
        sc.close();
    }
}
