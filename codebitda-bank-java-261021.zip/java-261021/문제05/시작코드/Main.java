import java.util.Scanner;

// TODO: Shipment, Trackable, Regular, Express, Desk를 조건에 맞게 작성하세요.
// TODO: Implement Shipment, Trackable, Regular, Express, and Desk as specified.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 배송 객체 생성·업캐스팅 후 show(s)를 호출하세요.
        // TODO: Create and upcast a shipment, then call show(s).
        // TODO: 특급은 타입 확인·다운캐스팅 후 show(e)와 인터페이스의 track()을 사용하세요.
        // TODO: For express, check the type, downcast, call show(e), and use track() through the interface.

        sc.close();
    }
}
