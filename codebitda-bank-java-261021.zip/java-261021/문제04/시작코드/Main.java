import java.util.Scanner;

abstract class Sim {
    protected String name;
    public Sim(String name) { this.name = name; }
    public void rest() { System.out.println(name + " rests"); }
    // 자식 클래스에서 구현할 추상 메소드입니다.
    // Subclasses must implement this abstract method.
    public abstract void act();
}
class ChildSim extends Sim {
    public ChildSim(String name) { super(name); }
    @Override
    public void act() { super.rest(); System.out.println(name + " plays"); }
    public void toy() { System.out.println("toy: blocks"); }
}
class YoungSim extends Sim {
    public YoungSim(String name) { super(name); }
    @Override
    public void act() { super.rest(); System.out.println(name + " studies"); }
    public void subject() { System.out.println("subject: Java"); }
}

class Reporter {
    public void report(Sim s) { System.out.println("type: Sim"); }
    public void report(ChildSim s) { System.out.println("type: ChildSim"); }
    public void report(YoungSim s) { System.out.println("type: YoungSim"); }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        int age = sc.nextInt();
        Reporter reporter = new Reporter();
        // TODO 1: 나이에 맞는 객체를 생성해 Sim 변수에 저장하세요.
        // TODO 1: Create the age-appropriate object and store it in a Sim variable.

        // TODO 2: 부모 타입으로 report와 act를 순서대로 호출하세요.
        // TODO 2: Call report and act in order using the parent-typed variable.

        // TODO 3: 실제 타입 확인·다운캐스팅 후 report와 전용 기능을 호출하세요.
        // TODO 3: Check the actual type, downcast, then call report and the specific feature.

        sc.close();
    }
}
