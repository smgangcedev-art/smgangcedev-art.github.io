import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int totalSeconds = sc.nextInt();
        // 하루는 24 * 60 * 60초, 한 시간은 60 * 60초입니다.
        // One day is 24 * 60 * 60 seconds; one hour is 60 * 60 seconds.
        int days = totalSeconds / (24 * 60 * 60);
        int hours = totalSeconds % (24 * 60 * 60) / (60 * 60);
        int minutes = totalSeconds % (60 * 60) / 60;
        int seconds = totalSeconds % 60;
        System.out.println("days: " + days);
        System.out.println("hours: " + hours);
        System.out.println("minutes: " + minutes);
        System.out.println("seconds: " + seconds);
        sc.close();
    }
}
