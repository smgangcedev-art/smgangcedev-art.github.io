import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int totalSeconds = sc.nextInt();
        // TODO 1: 네 변수의 초기값 0을 올바른 계산식으로 바꾸세요.
        // TODO 1: Replace the four zero initializers with the correct expressions.
        int days = 0;
        int hours = 0;
        int minutes = 0;
        int seconds = 0;
        System.out.println("days: " + days);
        System.out.println("hours: " + hours);
        System.out.println("minutes: " + minutes);
        System.out.println("seconds: " + seconds);
        sc.close();
    }
}
