#include <iostream>
#include <string>
using namespace std;

// Sim 클래스를 직접 선언하세요.
// Declare the Sim class yourself.
class Sim {

// private: 접근 지정자를 쓰고 string name과 int energy를 선언하세요.
// Write the private: access specifier and declare string name and int energy.
private:
    string name;
    int energy;

// public: 접근 지정자를 쓰고 아래 생성자·소멸자·멤버 함수를 작성하세요.
// Write the public: access specifier and define the constructors, destructor, and member functions below.
public:

// Sim(string n, int e): 이름과 에너지를 초기화하고 "생성되었습니다"를 한 줄 출력하세요.
// Sim(string n, int e): initialize the name and energy, then print "생성되었습니다" on one line.
    Sim(string n, int e) : name(n), energy(e) {
        cout << "생성되었습니다" << "\n";
    }

// Sim(): 매개변수 생성자에 위임하여 이름은 "Sim", 에너지는 100으로 설정하세요. 추가 출력은 없습니다.
// Sim(): delegate to the parameterized constructor with name "Sim" and energy 100. Do not print an extra message.
    Sim() : Sim("Sim", 100) {}

// ~Sim(): "소멸되었습니다"를 한 줄 출력하세요.
// ~Sim(): print "소멸되었습니다" on one line.
    ~Sim() {
        cout << "소멸되었습니다" << "\n";
    }

// void showInfo(): "name: 이름, energy: 에너지" 형식으로 한 줄 출력하세요.
// void showInfo(): print one line in the format "name: NAME, energy: ENERGY".
    void showInfo() {
        cout << "name: " << name << ", energy: " << energy << "\n";
    }

// void sleep(): 에너지를 20 올리고, 100을 넘으면 100으로 설정하세요. 함수 안에서는 출력하지 마세요.
// void sleep(): increase energy by 20 and cap it at 100. Do not print inside this function.
    void sleep() {
        energy += 20;
        if (energy > 100) {
            energy = 100;
        }
    }
};

int main() {
    // string name과 int energy를 선언하고 cin으로 이름과 에너지를 입력받으세요.
    // Declare string name and int energy, then read the name and energy using cin.
    string name;
    int energy;
    cin >> name >> energy;

    // 기본 생성자로 Sim 객체 a를 선언하세요.
    // Declare a Sim object named a using the default constructor.
    Sim a;

    // 입력한 이름과 에너지를 전달하여 Sim 객체 b를 선언하세요.
    // Declare a Sim object named b using the input name and energy.
    Sim b(name, energy);

    // a.showInfo(), b.showInfo() 순서로 호출하세요.
    // Call a.showInfo() and then b.showInfo().
    a.showInfo();
    b.showInfo();

    // b.sleep()을 한 번 호출한 뒤 b.showInfo()로 변경된 상태를 출력하세요.
    // Call b.sleep() once, then call b.showInfo() to print its updated state.
    b.sleep();
    b.showInfo();

    // main 종료 시 b, a 순서로 소멸자가 자동 호출됩니다.
    // When main ends, the destructors are called automatically for b and then a.
    return 0;
}
