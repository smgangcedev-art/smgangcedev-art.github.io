#include <iostream>
#include <string>
using namespace std;

// TODO: Sim 클래스를 직접 선언하세요.
// TODO: Declare the Sim class yourself.

// TODO: private: 접근 지정자를 쓰고 string name과 int energy를 선언하세요.
// TODO: Write the private: access specifier and declare string name and int energy.

// TODO: public: 접근 지정자를 쓰고 아래 생성자·소멸자·멤버 함수를 작성하세요.
// TODO: Write the public: access specifier and define the constructors, destructor, and member functions below.

// TODO: Sim(string n, int e): 이름과 에너지를 초기화하고 "생성되었습니다"를 한 줄 출력하세요.
// TODO: Sim(string n, int e): initialize the name and energy, then print "생성되었습니다" on one line.

// TODO: Sim(): 매개변수 생성자에 위임하여 이름은 "Sim", 에너지는 100으로 설정하세요. 추가 출력은 없습니다.
// TODO: Sim(): delegate to the parameterized constructor with name "Sim" and energy 100. Do not print an extra message.

// TODO: ~Sim(): "소멸되었습니다"를 한 줄 출력하세요.
// TODO: ~Sim(): print "소멸되었습니다" on one line.

// TODO: void showInfo(): "name: 이름, energy: 에너지" 형식으로 한 줄 출력하세요.
// TODO: void showInfo(): print one line in the format "name: NAME, energy: ENERGY".

// TODO: void sleep(): 에너지를 20 올리고, 100을 넘으면 100으로 설정하세요. 함수 안에서는 출력하지 마세요.
// TODO: void sleep(): increase energy by 20 and cap it at 100. Do not print inside this function.

int main() {
    // TODO: string name과 int energy를 선언하고 cin으로 이름과 에너지를 입력받으세요.
    // TODO: Declare string name and int energy, then read the name and energy using cin.

    // TODO: 기본 생성자로 Sim 객체 a를 선언하세요.
    // TODO: Declare a Sim object named a using the default constructor.

    // TODO: 입력한 이름과 에너지를 전달하여 Sim 객체 b를 선언하세요.
    // TODO: Declare a Sim object named b using the input name and energy.

    // TODO: a.showInfo(), b.showInfo() 순서로 호출하세요.
    // TODO: Call a.showInfo() and then b.showInfo().

    // TODO: b.sleep()을 한 번 호출한 뒤 b.showInfo()로 변경된 상태를 출력하세요.
    // TODO: Call b.sleep() once, then call b.showInfo() to print its updated state.

    // main 종료 시 b, a 순서로 소멸자가 자동 호출됩니다.
    // When main ends, the destructors are called automatically for b and then a.
    return 0;
}
