#include <iostream>
using namespace std;

int main() {
    char menu;
    int numbers[5];

    cin >> menu;

    // TODO: for 문으로 정수 5개를 배열에 입력하세요.


    return 0;
}