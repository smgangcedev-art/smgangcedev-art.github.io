#include <iostream>
using namespace std;

int main() {
    char menu;
    int numbers[5];

    cin >> menu;

    for (int i = 0; i < 5; i++) {
        cin >> numbers[i];
    }

    switch (menu) {
        case 'A':
            cout << "전체:";
            for (int i = 0; i < 5; i++) {
                cout << " " << numbers[i];
            }
            cout << '\n';
            break;
        case 'F':
            cout << "첫 값: " << numbers[0] << '\n';
            break;
        case 'L':
            cout << "마지막 값: " << numbers[4] << '\n';
            break;
        default:
            cout << "알 수 없는 명령" << '\n';
    }

    return 0;
}