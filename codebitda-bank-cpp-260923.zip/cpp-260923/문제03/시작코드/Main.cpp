#include <iostream>
using namespace std;

int main() {
    int menu;

    return 0;
}