#include <iostream>
using namespace std;

int main() {
    int menu;

    do {
        cout << "메뉴: 1-연습, 2-도움말, 0-종료" << '\n';
        cin >> menu;

        if (menu == 1) {
            cout << "연습 시작" << '\n';
        } else if (menu == 2) {
            cout << "도움말" << '\n';
        } else if (menu == 0) {
            cout << "프로그램 종료" << '\n';
        } else {
            cout << "잘못된 선택" << '\n';
        }
    } while (menu != 0);

    return 0;
}