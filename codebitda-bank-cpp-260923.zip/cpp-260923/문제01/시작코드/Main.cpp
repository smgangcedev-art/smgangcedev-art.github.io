#include <iostream>
#include <string>
using namespace std;


//TODO: printWord 함수 생성하기

// TODO: while 문으로 word를 count번 출력하세요.

int main() {
    string word;
    int count;

    cin >> word;
    cin >> count;

    // TODO: if 문으로 횟수를 확인한 뒤 함수를 호출하세요.

    return 0;
}