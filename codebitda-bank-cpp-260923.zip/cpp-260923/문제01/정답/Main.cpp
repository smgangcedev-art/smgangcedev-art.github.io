#include <iostream>
#include <string>
using namespace std;

void printWord(string word, int count) {
    int i = 0;

    while (i < count) {
        cout << word << '\n';
        i++;
    }
}

int main() {
    string word;
    int count;

    cin >> word;
    cin >> count;

    if (count >= 1 && count <= 3) {
        printWord(word, count);
    } else {
        cout << "횟수 오류" << '\n';
    }

    return 0;
}