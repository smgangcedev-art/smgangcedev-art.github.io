import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 데이터 / Given data
X = tf.constant([0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.6, 1.8, 2.0, 2.2], dtype=tf.float32)
Y = tf.constant([1.2, 1.3, 2.0, 2.1, 2.8, 2.9, 3.6, 3.7, 4.4, 4.5, 5.2, 5.3], dtype=tf.float32)
W = tf.Variable(0.0)
b = tf.Variable(0.0)
optimizer = tf.optimizers.SGD(learning_rate=0.05)

def cost_eval():
    prediction = W * X + b

    # 작성 1: 예측값과 Y의 MSE를 cost에 저장하세요.
    # Task 1: Store the MSE between prediction and Y in cost.
    cost = tf.reduce_mean(tf.square(prediction - Y))

    return cost

# 제공 코드: 10회와 1,000회 갱신 후 계수를 저장합니다.
# Provided: Save coefficients after 10 and 1,000 updates.
for step in range(1, 1001):
    with tf.GradientTape() as tape:
        cost = cost_eval()
    gradients = tape.gradient(cost, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))
    if step == 10:
        early_w, early_b = float(W.numpy()), float(b.numpy())
final_w, final_b = float(W.numpy()), float(b.numpy())

# 작성 2: X, Y의 평균과 최소제곱 기울기 a, y절편 c를 구하세요.
# Task 2: Compute the means of X and Y, least-squares slope a and intercept c.
mean_x = tf.reduce_mean(X)
mean_y = tf.reduce_mean(Y)
a = tf.reduce_sum((X - mean_x) * (Y - mean_y)) / tf.reduce_sum(tf.square(X - mean_x))
c = mean_y - a * mean_x

line_x = tf.linspace(0.0, 2.2, 100)

# 작성 3: 세 방법의 계수로 line_x에 대한 예측값을 계산하세요.
# Task 3: Predict at line_x using each set of coefficients.
# formula_y: 공식 / early_y: 10회 / final_y: 1,000회
# formula_y: formula / early_y: 10 updates / final_y: 1,000 updates
formula_y = a * line_x + c
early_y = early_w * line_x + early_b
final_y = final_w * line_x + final_b

# 제공 코드: 기울기와 y절편 출력 / Provided: Print slope and intercept
print(f'Formula: {float(a.numpy()):.3f} {float(c.numpy()):.3f}')
print(f'GD 10: {early_w:.3f} {early_b:.3f}')
print(f'GD 1000: {final_w:.3f} {final_b:.3f}')
print('graph ready')

# 제공 코드: 그래프 / Provided: Graph
plt.figure(figsize=(7, 4))
plt.scatter(X.numpy(), Y.numpy(), color='black', label='Data')
plt.plot(line_x.numpy(), formula_y.numpy(), color='blue', linewidth=3, label='Least Squares')
plt.plot(line_x.numpy(), early_y.numpy(), color='orange', linestyle='--', label='GD 10')
plt.plot(line_x.numpy(), final_y.numpy(), color='red', linestyle=':', linewidth=2, label='GD 1000')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Least Squares and Gradient Descent')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
