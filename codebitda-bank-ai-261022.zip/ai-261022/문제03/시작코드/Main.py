import tensorflow as tf

# 주어진 값 / Given values
X = [1.0, 2.0, 3.0]
Y = [2.0, 4.0, 5.0]
candidates = [(1.0, 1.0), (2.0, 0.0), (1.5, 0.5)]
new_values = [3.0, 4.0, 5.0]
lower = 5.5
upper = 6.5

# ──────────────────────────────────────
# 제공 코드: 비용 계산과 최적 모델 선택
# Provided: Compute costs and select the best model
# ──────────────────────────────────────
X = tf.constant(X, tf.float32)
Y = tf.constant(Y, tf.float32)
costs = [float(tf.reduce_mean(tf.square(w*X+b-Y)).numpy()) for w,b in candidates]
best = min(range(len(costs)), key=lambda i: costs[i])
w,b = candidates[best]

print(" ".join(f"{v:.3f}" for v in costs))
print(best+1)

# ──────────────────────────────────────
# 작성: 반복·예측·판정·출력
# Your task: Loop, predict, classify and print
# ──────────────────────────────────────
# new_values의 값을 순서대로 처리하는 반복문부터 작성하세요.
# Write a loop that processes the values in new_values in order.
# 각 값에 대해 선택된 w, b로 prediction을 계산하세요.
# Calculate prediction for each value using the selected w and b.
# upper 초과는 A, lower 미만은 B, 그 사이(양 끝 포함)는 C로 판정하세요.
# Assign A above upper, B below lower, and C between them (inclusive).
# 각 예측값(소수점 3자리)과 판정을 공백으로 구분하여 한 줄씩 출력하세요.
# Print each prediction (three decimal places) and label on one line, separated by a space.
