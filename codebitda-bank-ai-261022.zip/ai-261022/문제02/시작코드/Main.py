import tensorflow as tf

# 주어진 값은 변경하지 마세요.
# Do not change the given values.
x_values = [[1, 2, 3], [4, 5, 6]]
w_values = [[1], [2], [1]]
b_value = 2

X = tf.constant(x_values, dtype=tf.float64)
W = tf.Variable(w_values, dtype=tf.float64)
b = tf.Variable(b_value, dtype=tf.float64)
Y = tf.matmul(X, W) + b

# ──────────────────────────────────────
# 작성 1: 열별 평균 / Task 1: Column means
# ──────────────────────────────────────
# 각 열의 평균을 M(shape: (3,))에 저장하세요.
# Store the mean of each column in M (shape: (3,)).
# 여기에 코드를 작성하세요. / Write your code here.

# ──────────────────────────────────────
# 작성 2: 평균 보정 / Task 2: Center the columns
# ──────────────────────────────────────
# X의 각 열에서 해당 열의 평균을 빼 C를 만드세요.
# Subtract each column mean from X to obtain C.
# 여기에 코드를 작성하세요. / Write your code here.

# ──────────────────────────────────────
# 작성 3: 보정 후 예측 / Task 3: Predictions after centering
# ──────────────────────────────────────
# 보정된 C에 기존 W와 b를 적용한 예측값 Z를 구하세요.
# Compute predictions Z from C using the existing W and b.
# 여기에 코드를 작성하세요. / Write your code here.

# ──────────────────────────────────────
# 제공 코드: 출력 / Provided: Output
# ──────────────────────────────────────
print(" ".join(f"{v:.2f}" for v in Y.numpy().ravel()))
print(" ".join(f"{v:.2f}" for v in M.numpy().ravel()))
print(" ".join(f"{v:.2f}" for v in Z.numpy().ravel()))
