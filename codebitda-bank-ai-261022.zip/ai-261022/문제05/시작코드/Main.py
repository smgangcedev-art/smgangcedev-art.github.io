import tensorflow as tf
import matplotlib.pyplot as plt

# 제공 코드: 전체 데이터와 가운데 구간 분리
# Provided: Full data and separation of the middle interval
all_X = tf.constant([-1.5, -1.25, -1.0, -0.75, -0.5, 0.0, 0.5, 0.75, 1.0, 1.25, 1.5], dtype=tf.float32)
all_Y = tf.constant([-0.375, 0.11, 0.4, 0.645, 0.825, 1.05, 1.375, 1.695, 2.2, 2.89, 3.775], dtype=tf.float32)
train_mask = tf.abs(all_X) > 0.5
X = tf.boolean_mask(all_X, train_mask)
Y = tf.boolean_mask(all_Y, train_mask)
check_X = tf.boolean_mask(all_X, ~train_mask)
check_Y = tf.boolean_mask(all_Y, ~train_mask)
a0, a1, a2, a3 = [tf.Variable(0.0) for _ in range(4)]
optimizer = tf.optimizers.SGD(learning_rate=0.01)

def predict(x):
    # 작성 1: 3차식의 예측값을 hypothesis에 저장하세요.
    # Task 1: Store the cubic prediction in hypothesis.
    # 여기에 코드를 작성하세요. / Write your code here.

    return hypothesis

def cost_eval():
    prediction = predict(X)

    # 작성 2: 학습 데이터 X, Y에 대한 MSE를 cost에 저장하세요.
    # Task 2: Store the MSE for training data X, Y in cost.
    # 여기에 코드를 작성하세요. / Write your code here.

    return cost

# 제공 코드: 양쪽 구간 데이터만 사용하여 1,000회 갱신
# Provided: 1,000 updates using only the data on both sides
for _ in range(1000):
    with tf.GradientTape() as tape:
        current_cost = cost_eval()
    gradients = tape.gradient(current_cost, [a0, a1, a2, a3])
    optimizer.apply_gradients(zip(gradients, [a0, a1, a2, a3]))

# 작성 3: 가운데 구간의 예측값과 MAE를 계산하세요.
# Task 3: Calculate predictions and MAE for the middle interval.
# check_prediction: check_X의 예측 / Predictions at check_X
# mae: check_Y와 예측값의 차이의 절댓값을 평균 / Mean absolute difference from check_Y
# 여기에 코드를 작성하세요. / Write your code here.

# 제공 코드: 출력 / Provided: Output
for x, value in zip(check_X.numpy(), check_prediction.numpy()):
    print(f'{x:.1f} {value:.3f}')
print(f'MAE: {float(mae.numpy()):.3f}')
print('graph ready')

# 제공 코드: 그래프 / Provided: Graph
new_X = tf.linspace(-1.5, 1.5, 200)
new_Y = predict(new_X)
plt.figure(figsize=(7, 4))
plt.axvspan(-0.5, 0.5, color='gray', alpha=0.15, label='Held-out Interval')
plt.scatter(X.numpy(), Y.numpy(), color='black', label='Training Data')
plt.plot(new_X.numpy(), new_Y.numpy(), 'b-', label='Cubic Prediction')
plt.scatter(check_X.numpy(), check_Y.numpy(), color='red', marker='s', label='Held-out Actual')
plt.scatter(check_X.numpy(), check_prediction.numpy(), color='green', marker='x', s=70, label='Held-out Prediction')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Predicting the Missing Middle')
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
