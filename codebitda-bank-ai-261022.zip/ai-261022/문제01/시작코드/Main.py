# 대괄호 안에 답을 작성하세요.
# Write each answer inside the brackets.
print("1. []")
print("2. []")
print("3. []")
print("4. []")
