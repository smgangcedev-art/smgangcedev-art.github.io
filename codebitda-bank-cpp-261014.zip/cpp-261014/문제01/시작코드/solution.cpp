#include <iostream>
#include <string>
using namespace std;

// TODO: Sim 클래스를 선언하세요. private에 string name, int energy를 선언하세요.
// TODO: Declare Sim with private fields string name and int energy.

// TODO: public에 Sim(string n, int e)를 작성하여 이름과 에너지를 초기화하세요.
// TODO: Under public, define Sim(string n, int e) to initialize the name and energy.

// TODO: public 함수 void showInfo()는 "name: 이름, energy: 에너지"를 한 줄 출력합니다.
// TODO: Public void showInfo() prints one line as "name: NAME, energy: ENERGY".

// TODO: public 함수 void useEnergy(int amount)는 에너지를 amount만큼 줄입니다. 0 미만이면 0으로 설정하세요.
// TODO: Public void useEnergy(int amount) reduces energy by amount, with a minimum of 0.

// TODO: public 함수 void sleep()은 에너지를 20 올립니다. 100을 넘으면 100으로 설정하세요.
// TODO: Public void sleep() increases energy by 20, with a maximum of 100.

// TODO: YoungSim 클래스를 Sim의 public 상속으로 선언하세요.
// TODO: Declare YoungSim as a public subclass of Sim.

// TODO: public 생성자 YoungSim(string n, int e)는 초기화 목록에서 Sim(n, e)를 호출합니다.
// TODO: The public YoungSim(string n, int e) constructor calls Sim(n, e) in its initializer list.

// TODO: public 함수 void study()는 상속받은 useEnergy()를 호출하여 에너지를 20 소비합니다.
// TODO: Public void study() calls the inherited useEnergy() to consume 20 energy.

// TODO: ChildSim 클래스를 Sim의 public 상속으로 선언하세요.
// TODO: Declare ChildSim as a public subclass of Sim.

// TODO: public 생성자 ChildSim(string n, int e)는 초기화 목록에서 Sim(n, e)를 호출합니다.
// TODO: The public ChildSim(string n, int e) constructor calls Sim(n, e) in its initializer list.

// TODO: public 함수 void play()는 상속받은 useEnergy()를 호출하여 에너지를 10 소비합니다.
// TODO: Public void play() calls the inherited useEnergy() to consume 10 energy.

int main() {
    // TODO: 두 캐릭터의 이름과 에너지를 저장할 변수를 선언하고 cin으로 차례로 입력받으세요.
    // TODO: Declare variables and use cin to read the name and energy of each character in order.

    // TODO: 입력값으로 YoungSim 객체 young과 ChildSim 객체 child를 생성하세요.
    // TODO: Create a YoungSim object named young and a ChildSim object named child using the input values.

    // TODO: young, child 순서로 상속받은 showInfo()를 호출하여 초기 상태를 출력하세요.
    // TODO: Call the inherited showInfo() on young and then child to print their initial states.

    // TODO: young.study()와 child.play()를 각각 한 번 호출한 뒤 young, child 순서로 상태를 출력하세요.
    // TODO: Call young.study() and child.play() once each, then print their states in young, child order.

    // TODO: 두 객체의 상속받은 sleep()을 각각 한 번 호출한 뒤 young, child 순서로 상태를 출력하세요.
    // TODO: Call the inherited sleep() once on each object, then print their states in young, child order.

    return 0;
}
