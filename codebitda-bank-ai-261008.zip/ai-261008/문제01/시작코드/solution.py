import tensorflow as tf
import matplotlib.pyplot as plt

# TODO 1: tf.constant()로 [2.0, 4.0, 6.0, 8.0]을 담은 텐서 data를 만드세요.
# TODO 1: Create a tensor named data containing [2.0, 4.0, 6.0, 8.0] with tf.constant().

# TODO 2: tf.reduce_mean(data)로 평균을 구하여 average에 저장하세요.
# TODO 2: Use tf.reduce_mean(data) to calculate the mean and store it in average.

# TODO 3: data.numpy()로 텐서를 NumPy 배열로 변환하여 values에 저장하세요.
# TODO 3: Convert the tensor to a NumPy array with data.numpy() and store it in values.

# 평균을 먼저 출력합니다. 이 코드는 수정하지 마세요.
# Print the mean first. Do not change this code.
print("mean:", average.numpy())

# 가로축 값은 제공됩니다.
# The x-axis values are provided.
x = [1, 2, 3, 4]

# TODO 4: plt.plot()에 x와 values를 전달하여 선 그래프를 그리세요. marker="o"를 사용하세요.
# TODO 4: Pass x and values to plt.plot() to draw a line chart. Use marker="o".

# 제목과 축 이름은 제공됩니다.
# The title and axis labels are provided.
plt.title("Tensor Values")
plt.xlabel("Index")
plt.ylabel("Value")
plt.xticks(x)

# TODO 5: plt.show()로 그래프를 표시하세요.
# TODO 5: Display the graph with plt.show().

print("그래프 생성 완료")
