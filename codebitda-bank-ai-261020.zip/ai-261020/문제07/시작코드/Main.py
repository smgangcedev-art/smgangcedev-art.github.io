import tensorflow as tf

# 주어진 값 / Given values
X = [1.0, 2.0, 3.0]
Y = [1.0, 2.0, 3.0]
initial_W = 0.0
initial_b = 0.0
learning_rate = 0.1

# 조건에 맞게 계산하고 결과를 출력하세요.
# Complete the calculations and output as specified.
