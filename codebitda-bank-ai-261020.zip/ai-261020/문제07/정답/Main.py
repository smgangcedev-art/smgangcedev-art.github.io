import tensorflow as tf

# 주어진 값 / Given values
X = [1.0, 2.0, 3.0]
Y = [1.0, 2.0, 3.0]
initial_W = 0.0
initial_b = 0.0
learning_rate = 0.1

X = tf.constant(X, dtype=tf.float32)
Y = tf.constant(Y, dtype=tf.float32)
W = tf.Variable(initial_W)
b = tf.Variable(initial_b)
optimizer = tf.optimizers.SGD(learning_rate=learning_rate)
def cost_eval():
    hypothesis = W * X + b
    return tf.reduce_mean(tf.square(hypothesis-Y))
initial_cost = float(cost_eval().numpy())
for _ in range(2):
    with tf.GradientTape() as tape:
        current_cost = cost_eval()
    gradients = tape.gradient(current_cost, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))
    print(f"{W.numpy():.3f} {b.numpy():.3f}")
print(f"{initial_cost-float(cost_eval().numpy()):.3f}")
