import tensorflow as tf

# 주어진 값은 변경하지 마세요.
# Do not change the given values.
values = [[1, 2, 3], [1, 1, 1]]

# 조건에 맞는 텐서 생성, 연산 및 출력을 작성하세요.
# Create the tensors and implement the required operations and output.
