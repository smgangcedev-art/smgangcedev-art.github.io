import tensorflow as tf

# 주어진 값은 변경하지 마세요.
# Do not change the given values.
values = [[1, 2, 3], [1, 1, 1]]

x = tf.constant(values, dtype=tf.float64)
print(f"{tf.reduce_sum(x).numpy():.2f}")
print(" ".join(f"{v:.2f}" for v in tf.reduce_sum(x, axis=0).numpy()))
print(" ".join(f"{v:.2f}" for v in tf.reduce_mean(x, axis=1).numpy()))
