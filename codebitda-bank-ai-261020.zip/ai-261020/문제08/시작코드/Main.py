import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 값 / Given values
X = [1.0, 2.0, 3.0]
Y = [1.0, 2.0, 3.0]
w_start = -3.5
w_stop = 5.5
w_step = 0.1

# 조건에 맞게 계산하고 결과를 출력하세요.
# Complete the calculations and output as specified.
