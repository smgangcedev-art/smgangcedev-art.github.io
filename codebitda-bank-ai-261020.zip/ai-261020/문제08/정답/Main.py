import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 값 / Given values
X = [1.0, 2.0, 3.0]
Y = [1.0, 2.0, 3.0]
w_start = -3.5
w_stop = 5.5
w_step = 0.1

X = tf.constant(X, dtype=tf.float32)
Y = tf.constant(Y, dtype=tf.float32)
plt.figure(figsize=(7,4))
for bias, style in [(0.0, 'r-'), (1.0, 'b--')]:
    W_val, cost_val = [], []
    for feed_W in tf.range(w_start, w_stop, w_step):
        hypothesis = X*feed_W+bias
        cost = tf.reduce_mean(tf.square(hypothesis-Y))
        W_val.append(float(feed_W.numpy()))
        cost_val.append(float(cost.numpy()))
    plt.plot(W_val, cost_val, style, label=f'b={bias:.0f}')
plt.xlabel('W')
plt.ylabel('cost')
plt.title('Weight and Cost')
plt.legend()
plt.tight_layout()
print('graph ready')
plt.show()
