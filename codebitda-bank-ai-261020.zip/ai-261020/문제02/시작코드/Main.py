import tensorflow as tf

# 주어진 값 / Given values
values = [1, 2, 3, 4, 5, 6]

# 텐서 생성, 모양 변경, 전치 및 출력을 작성하세요.
# Create, reshape and transpose the tensor, then print the results.
