import tensorflow as tf

values = [1, 2, 3, 4, 5, 6]
x = tf.reshape(tf.constant(values, dtype=tf.int32), (2, 3))
y = tf.transpose(x)
print(int(tf.rank(x).numpy()))
print(*x.shape)
print(*y.shape)
for row in y.numpy():
    print(*row)
