import tensorflow as tf

X = [1.0, 2.0, 3.0]
Y = [2.0, 4.0, 5.0]
candidates = [(1.0, 1.0), (2.0, 0.0), (1.5, 0.5)]
new_x = 4.0
X = tf.constant(X, tf.float32)
Y = tf.constant(Y, tf.float32)
costs = [float(tf.reduce_mean(tf.square(w*X+b-Y)).numpy()) for w,b in candidates]
best = min(range(len(costs)), key=lambda i: costs[i])
w,b = candidates[best]
print(" ".join(f"{v:.3f}" for v in costs))
print(best+1)
print(f"{w*new_x+b:.3f}")
