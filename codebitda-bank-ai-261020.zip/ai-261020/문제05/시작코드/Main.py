import tensorflow as tf

X = [1.0, 2.0, 3.0]
Y = [2.0, 4.0, 5.0]
candidates = [(1.0, 1.0), (2.0, 0.0), (1.5, 0.5)]
new_x = 4.0

# 조합별 비용과 최적 모델의 예측을 계산하세요.
# Compare costs and predict with the best model.
