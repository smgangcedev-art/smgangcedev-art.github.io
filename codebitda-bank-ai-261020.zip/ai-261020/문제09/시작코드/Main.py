import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 값 / Given values
X = [0, 0.5, 1.0, 1.5, 2.0, 2.5]
Y = [0.3, 1.9, 2.4, 4.1, 6.8, 7.9]
learning_rate = 0.01
epochs = 1000

# 조건에 맞게 계산하고 결과를 출력하세요.
# Complete the calculations and output as specified.
