import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 값 / Given values
X = [0, 0.5, 1.0, 1.5, 2.0, 2.5]
Y = [0.3, 1.9, 2.4, 4.1, 6.8, 7.9]
learning_rate = 0.01
epochs = 1000

X = tf.constant(X, dtype=tf.float32)
Y = tf.constant(Y, dtype=tf.float32)
test_X, test_Y = X[-1:], Y[-1:]
X, Y = X[:-1], Y[:-1]
W = tf.Variable(0.0)
b = tf.Variable(0.0)
optimizer = tf.optimizers.SGD(learning_rate=learning_rate)
def cost_eval():
    hypothesis = W*X+b
    return tf.reduce_mean(tf.square(hypothesis-Y))
for epoch in range(epochs):
    # 자동미분으로 모든 계수를 함께 갱신합니다.
    # Update all coefficients together using automatic differentiation.
    with tf.GradientTape() as tape:
        current_cost = cost_eval()
    gradients = tape.gradient(current_cost, [W, b])
    optimizer.apply_gradients(zip(gradients, [W, b]))
new_X = tf.range(0.0, 3.0, 0.05)
new_Y = W*new_X+b
plt.figure(figsize=(7,4))
plt.plot(X.numpy(), Y.numpy(), 'ro', label='Sample Data')
plt.plot(new_X.numpy(), new_Y.numpy(), 'b-', label='Regression Line')
plt.plot(test_X.numpy(), test_Y.numpy(), 'ks', label='Held-out Actual')
plt.plot(test_X.numpy(), (W*test_X+b).numpy(), 'gx', markersize=10, label='Held-out Prediction')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Linear Regression')
plt.legend()
plt.grid(True)
plt.tight_layout()
print('graph ready')
plt.show()
