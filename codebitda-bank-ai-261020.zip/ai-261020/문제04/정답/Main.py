import tensorflow as tf

# 주어진 값은 변경하지 마세요.
# Do not change the given values.
x_values = [[1, 2, 3], [4, 5, 6]]
w_values = [[1], [2], [1]]
b_value = 2

X = tf.constant(x_values, dtype=tf.float64)
W = tf.Variable(w_values, dtype=tf.float64)
b = tf.Variable(b_value, dtype=tf.float64)
Y = tf.matmul(X, W) + b
print(" ".join(f"{v:.2f}" for v in Y.numpy().ravel()))
