import tensorflow as tf
import matplotlib.pyplot as plt

# 주어진 값 / Given values
X = [0, 0.5, 1.0, 1.5, 2.0, 2.5]
Y = [0.3, 1.9, 2.4, 4.1, 6.8, 7.9]
learning_rate = 0.001
epochs = 1000

X = tf.constant(X, dtype=tf.float32)
Y = tf.constant(Y, dtype=tf.float32)
a0, a1, a2, a3 = [tf.Variable(0.0) for _ in range(4)]
optimizer = tf.optimizers.SGD(learning_rate=learning_rate)
def cost_eval():
    hypothesis = a0+a1*X+a2*X**2+a3*X**3
    return tf.reduce_mean(tf.square(hypothesis-Y))
early = None
for epoch in range(epochs):
    # 자동미분으로 모든 계수를 함께 갱신합니다.
    # Update all coefficients together using automatic differentiation.
    with tf.GradientTape() as tape:
        current_cost = cost_eval()
    gradients = tape.gradient(current_cost, [a0, a1, a2, a3])
    optimizer.apply_gradients(zip(gradients, [a0, a1, a2, a3]))
    if epoch == 99:
        early = [float(v.numpy()) for v in [a0,a1,a2,a3]]
new_X = tf.range(0.0, 3.0, 0.05)
new_Y = a0+a1*new_X+a2*new_X**2+a3*new_X**3
plt.figure(figsize=(7,4))
plt.plot(X.numpy(), Y.numpy(), 'ro', label='Sample Data')
plt.plot(new_X.numpy(), new_Y.numpy(), 'b-', label='Epoch 1000')
early_Y = early[0]+early[1]*new_X+early[2]*new_X**2+early[3]*new_X**3
plt.plot(new_X.numpy(), early_Y.numpy(), 'g--', label='Epoch 100')
plt.xlabel('X')
plt.ylabel('Y')
plt.title('Cubic Regression')
plt.legend()
plt.grid(True)
plt.tight_layout()
print('graph ready')
plt.show()
