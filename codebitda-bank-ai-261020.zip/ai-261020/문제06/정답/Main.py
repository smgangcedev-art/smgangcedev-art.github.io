import tensorflow as tf

# 주어진 값 / Given values
X = [0, 0.5, 1.0, 1.5, 2.0, 2.5]
Y = [0.3, 1.9, 2.4, 4.1, 6.8, 7.9]
test_x, test_y = X[-1], Y[-1]
X, Y = X[:-1], Y[:-1]

x_mean = sum(X)/len(X)
y_mean = sum(Y)/len(Y)
division = sum((y-y_mean)*(x-x_mean) for y,x in zip(Y,X))
divisor = sum((x-x_mean)**2 for x in X)
a = division/divisor
b = y_mean-a*x_mean
new_y = a*test_x+b
print(f"{a:.3f} {b:.3f}")
print(f"{new_y:.3f}")
print(f"{abs(new_y-test_y):.3f}")
