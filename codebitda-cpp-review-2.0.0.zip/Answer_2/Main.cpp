#include <iostream>
using namespace std;

class Card {
private:
    int balance;
public:
    Card(int amount) : balance(amount) {}
    void pay(int amount) { balance -= amount; }
    int getBalance() { return balance; }
};

int main() {
    Card card(100);
    card.pay(20);
    cout << card.getBalance() << "\n";
    return 0;
}
