CODEBITDA-CPP 2.0.0 REVIEW KIT
All files contain synthetic data only. No account passwords or server credentials are included.

1. Sign in using Instructor/Assistant sign-in and the review account provided privately in Partner Center.
2. Select Edit existing exam, open Review_Exam.json, then SAVE it to a new file such as Connected_Review_Exam.json. This creates the review folder in your connected Drive and binds the saved exam to that instructor. Use this SAVED file for student submission tests. The original template intentionally has no submission connection.
3. Return home, choose Assignment mode, and load Connected_Review_Exam.json. Enter REVIEW001 and ReviewStudent if asked for student details.
4. Question 1: paste Answer_1/Main.cpp. Interactive run: enter 2 3, expect 5. Automatic grading should pass all three cases and award 10 points. To check input waiting, wait over 10 seconds before typing; the interactive wall limit is 300 seconds.
5. Question 2: paste Answer_2/Main.cpp. Run interactively and expect 80. The instructor reviews the Card class, so this question remains pending manual grading.
6. Submit. Confirm the answer JSON and submission roster in the review account's STORE_REVIEW_CPP_200 Drive folder. Submit a changed answer again to check submission history.
7. Grading: return to instructor home and open Grading. Select a LOCAL folder containing Sample_Submission.json (or the actual submitted result). Review both sources. The sample is deliberately 10 auto-graded points plus 10 points awaiting manual review; it is not a real student submission.
8. Examination mode can use the same saved exam. Unlike Assignment mode, examination mode enables exam window restrictions and secondary-monitor covers. Do not switch applications during an active examination test; use the in-app exit/home action to finish.

Expected results: sum outputs 5, 5, 0; Card outputs 80. Total available score: 20. A reviewer must assess Card class manually.

한국어 안내
교수자로 로그인 → 기존문제 수정에서 Review_Exam.json 열기 → 다른 이름으로 저장하여 Drive 제출 연결 생성.
학생 과제/시험 모드에서는 새로 저장한 문제지를 사용하세요. 1번은 합산 자동채점, 2번은 Card class 클래스 수동채점입니다.
Answer_1과 Answer_2의 Main.cpp를 각각 해당 문제에 붙여넣으세요.
Sample_Submission.json은 채점 화면 확인용 가상 결과이며 Card class 점수는 미채점 상태입니다.
