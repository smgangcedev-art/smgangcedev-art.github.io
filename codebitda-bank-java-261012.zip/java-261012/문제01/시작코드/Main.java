import java.util.Scanner;

class Sim {
    // 공통 정보는 private 필드에 저장합니다.
    // Store shared information in private fields.
    private String name;
    private int age;

    public Sim(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void showInfo() {
        System.out.println("name: " + name + ", age: " + age);
    }
}

// TODO: Sim을 상속하는 ChildSim 클래스를 작성하세요.
// TODO: Write ChildSim as a subclass of Sim.
// public ChildSim(String name, int age)에서 super(name, age)를 호출하세요.
// Call super(name, age) in public ChildSim(String name, int age).
// public void play(): getName()으로 이름을 얻어 "이름 plays"를 출력하세요.
// public void play(): use getName() to print "NAME plays".

// TODO: Sim을 상속하는 YoungSim 클래스를 작성하세요.
// TODO: Write YoungSim as a subclass of Sim.
// public YoungSim(String name, int age)에서 super(name, age)를 호출하세요.
// Call super(name, age) in public YoungSim(String name, int age).
// public void study(): getName()으로 이름을 얻어 "이름 studies"를 출력하세요.
// public void study(): use getName() to print "NAME studies".

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        int age = sc.nextInt();

        // TODO: Sim 타입 변수 sim을 선언하세요.
        // TODO: Declare a variable named sim of type Sim.
        // 1~12세는 ChildSim, 13~19세는 YoungSim을 생성하여 sim에 대입하세요(업캐스팅).
        // Create a ChildSim for ages 1-12 or a YoungSim for ages 13-19 and assign it to sim (upcasting).

        // TODO: sim.showInfo()로 공통 정보를 출력하세요.
        // TODO: Print the shared information using sim.showInfo().

        // TODO: instanceof로 sim의 실제 타입을 확인하세요.
        // TODO: Check the actual type of sim using instanceof.
        // ChildSim이면 (ChildSim)으로 명시적 다운캐스팅한 뒤 play()를 호출하세요.
        // If it is a ChildSim, explicitly downcast with (ChildSim), then call play().
        // YoungSim이면 (YoungSim)으로 명시적 다운캐스팅한 뒤 study()를 호출하세요.
        // If it is a YoungSim, explicitly downcast with (YoungSim), then call study().

        sc.close();
    }
}
