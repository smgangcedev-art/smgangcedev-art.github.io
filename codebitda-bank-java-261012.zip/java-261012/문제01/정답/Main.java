import java.util.Scanner;

class Sim {
    // 공통 정보는 private 필드에 저장합니다.
    // Store shared information in private fields.
    private String name;
    private int age;

    public Sim(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void showInfo() {
        System.out.println("name: " + name + ", age: " + age);
    }
}

class ChildSim extends Sim {
    public ChildSim(String name, int age) {
        // 부모 생성자로 공통 정보를 초기화합니다.
        // Initialize shared information with the parent constructor.
        super(name, age);
    }

    public void play() {
        System.out.println(getName() + " plays");
    }
}

class YoungSim extends Sim {
    public YoungSim(String name, int age) {
        // 부모 생성자로 공통 정보를 초기화합니다.
        // Initialize shared information with the parent constructor.
        super(name, age);
    }

    public void study() {
        System.out.println(getName() + " studies");
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        int age = sc.nextInt();

        // 자식 객체를 부모 타입 변수에 대입합니다(업캐스팅).
        // Assign a subclass object to a superclass variable (upcasting).
        Sim sim;
        if (age <= 12) {
            sim = new ChildSim(name, age);
        } else {
            sim = new YoungSim(name, age);
        }
        sim.showInfo();

        // 타입을 확인한 뒤 명시적으로 다운캐스팅하여 전용 함수를 호출합니다.
        // Check the type, explicitly downcast, then call the subclass-specific method.
        if (sim instanceof ChildSim) {
            ChildSim child = (ChildSim) sim;
            child.play();
        } else if (sim instanceof YoungSim) {
            YoungSim young = (YoungSim) sim;
            young.study();
        }
        sc.close();
    }
}
