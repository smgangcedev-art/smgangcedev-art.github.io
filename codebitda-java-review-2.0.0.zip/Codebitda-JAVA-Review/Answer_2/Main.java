import javax.swing.*;
import java.awt.*;
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Review Counter");
            JLabel label = new JLabel("Count: 0");
            JButton button = new JButton("Add 1");
            int[] count = {0};
            button.addActionListener(e -> label.setText("Count: " + (++count[0])));
            frame.setLayout(new FlowLayout());
            frame.add(label);
            frame.add(button);
            frame.setSize(320, 180);
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
