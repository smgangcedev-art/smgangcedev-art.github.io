import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine(); // 정수 뒤에 남은 줄바꿈 제거
        // Consume the newline after the integer.

        try {
            FileWriter writer = new FileWriter("memo_261104.txt");

            // TODO 1: N줄을 입력받아 줄바꿈과 함께 파일에 저장하고 writer를 닫으세요.
            // TODO 1: Read N lines, save each line with a newline, and close writer.
            // 여기에 작성하세요.
            // Write your code here.

            FileReader reader = new FileReader("memo_261104.txt");
            int c;
            int lines = 0;
            int chars = 0;

            // TODO 2: 파일을 끝까지 읽고 출력하며 lines와 chars를 계산한 뒤 reader를 닫으세요.
            // TODO 2: Read and display the file, count lines and chars, then close reader.
            // 여기에 작성하세요.
            // Write your code here.

            // 제공 코드: 출력 형식은 수정하지 마세요.
            // Provided code: do not change the output format.
            System.out.println("lines: " + lines);
            System.out.println("chars: " + chars);
        } catch (IOException e) {
            System.out.println("file error");
        }
        sc.close();
    }
}
