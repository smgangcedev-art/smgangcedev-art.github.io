import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine(); // Consume the newline after the integer.

        try {
            FileWriter writer = new FileWriter("memo_261104.txt");

            // TODO 1: Read N lines, save each line with a newline, and close writer.
            // Write your code here.

            FileReader reader = new FileReader("memo_261104.txt");
            int c;
            int lines = 0;
            int chars = 0;

            // TODO 2: Read and display the file, count lines and chars, then close reader.
            // Write your code here.

            // Provided code: do not change the output format.
            System.out.println("lines: " + lines);
            System.out.println("chars: " + chars);
        } catch (IOException e) {
            System.out.println("file error");
        }
        sc.close();
    }
}
