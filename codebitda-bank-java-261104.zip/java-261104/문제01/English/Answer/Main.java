import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        int total = 0;

        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            String name = sc.next();
            int score = sc.nextInt();

            // TODO 1: Add name to names.
            names.add(name);
            // TODO 2: Add score to scores.
            scores.add(score);
            // TODO 3: Add score to total.
            total += score;
        }

        // The file I/O structure below is provided. Complete only TODO 4 and TODO 5.
        try {
            FileWriter writer = new FileWriter("scores_261104.txt");
            writer.write("students: " + names.size() + "\n");

            for (int i = 0; i < names.size(); i++) {
                String name = names.get(i);
                int score = scores.get(i);
                // TODO 4: Write "name score" followed by a newline to the file.
                writer.write(name + " " + score + "\n");
            }
            // TODO 5: Write "total: sum" followed by a newline to the file.
            writer.write("total: " + total + "\n");
            writer.close();

            // Provided code: read the saved file and display its contents.
            FileReader reader = new FileReader("scores_261104.txt");
            int c;
            while ((c = reader.read()) != -1) {
                System.out.print((char) c);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("file error");
        }
        sc.close();
    }
}
