import java.io.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> names = new ArrayList<String>();
        ArrayList<Integer> scores = new ArrayList<Integer>();
        int total = 0;

        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            String name = sc.next();
            int score = sc.nextInt();

            // TODO 1: name을 names에 추가하세요.
            // TODO 1: Add name to names.
            names.add(name);
            // TODO 2: score를 scores에 추가하세요.
            // TODO 2: Add score to scores.
            scores.add(score);
            // TODO 3: score를 total에 더하세요.
            // TODO 3: Add score to total.
            total += score;
        }

        // 아래 파일 입출력 틀은 제공됩니다. TODO 4, 5만 작성하세요.
        // The file I/O structure below is provided. Complete only TODO 4 and TODO 5.
        try {
            FileWriter writer = new FileWriter("scores_261104.txt");
            writer.write("students: " + names.size() + "\n");

            for (int i = 0; i < names.size(); i++) {
                String name = names.get(i);
                int score = scores.get(i);
                // TODO 4: "이름 점수"와 줄바꿈을 파일에 기록하세요.
                // TODO 4: Write "name score" followed by a newline to the file.
                writer.write(name + " " + score + "\n");
            }
            // TODO 5: "total: 합계"와 줄바꿈을 파일에 기록하세요.
            // TODO 5: Write "total: sum" followed by a newline to the file.
            writer.write("total: " + total + "\n");
            writer.close();

            // 제공 코드: 저장된 파일을 읽어 화면에 출력합니다.
            // Provided code: read the saved file and display its contents.
            FileReader reader = new FileReader("scores_261104.txt");
            int c;
            while ((c = reader.read()) != -1) {
                System.out.print((char) c);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("file error");
        }
        sc.close();
    }
}
