import matplotlib.pyplot as plt
x = [1, 2, 3]
y = [2, 4, 3]
plt.plot(x, y)
plt.show()
