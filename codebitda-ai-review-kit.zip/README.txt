AI 2.0.0 review kit
Open Review_Exam.json in Assignment mode. No student login is required.
Use REVIEW001_ReviewStudent as the synthetic student identifier.
Paste Answer1.py for automatic grading (2.0). Paste Answer2.py for a line plot; its score requires instructor review.
Instructor login credentials are supplied privately in Partner Center.
To test cloud submission, an approved instructor should open and save this exam to connect it to their Drive first.
The first run prepares the bundled libraries. Wait for preparation to finish.
