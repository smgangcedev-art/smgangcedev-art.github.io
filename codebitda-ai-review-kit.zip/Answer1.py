import tensorflow as tf
values = tf.constant([1.0, 2.0, 3.0])
print(float(tf.reduce_mean(values).numpy()))
