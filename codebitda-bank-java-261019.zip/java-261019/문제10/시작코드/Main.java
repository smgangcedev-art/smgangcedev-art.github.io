import java.util.Scanner;

// TODO: Named와 이를 구현하는 Member를 작성하세요. id는 객체별, count는 static으로 공유합니다.
// TODO: Write Named and Member. Each object has its own id; count is shared as static.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: n개의 Member를 Named[]에 모두 저장한 후 출력하고 Member.getCount()를 호출하세요.
        // TODO: Store all n Members in Named[], print them, then call Member.getCount().
        
        sc.close();
    }
}
