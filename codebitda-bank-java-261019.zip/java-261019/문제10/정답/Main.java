import java.util.Scanner;

interface Named {
    String getName();
    int getId();
}
class Member implements Named {
    private String name;
    private int id;
    // 모든 Member 객체가 count 하나를 공유합니다.
    // All Member objects share one count field.
    private static int count = 0;
    public Member(String name) { this.name = name; count++; this.id = count; }
    @Override
    public String getName() { return name; }
    @Override
    public int getId() { return id; }
    public static int getCount() { return count; }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        Named[] members = new Named[n];
        for (int i = 0; i < n; i++) members[i] = new Member(sc.next());
        for (int i = 0; i < n; i++) {
            System.out.println(members[i].getId() + " " + members[i].getName());
        }
        System.out.println("count: " + Member.getCount());
        sc.close();
    }
}
