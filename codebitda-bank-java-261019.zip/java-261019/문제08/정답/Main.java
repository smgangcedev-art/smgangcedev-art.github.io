import java.util.Scanner;

abstract class Sim {
    protected String name;
    public Sim(String name) { this.name = name; }
    public void rest() { System.out.println(name + " rests"); }
    // 자식 클래스에서 구현할 추상 메소드입니다.
    // Subclasses must implement this abstract method.
    public abstract void act();
}
class ChildSim extends Sim {
    public ChildSim(String name) { super(name); }
    @Override
    public void act() { super.rest(); System.out.println(name + " plays"); }
    public void toy() { System.out.println("toy: blocks"); }
}
class YoungSim extends Sim {
    public YoungSim(String name) { super(name); }
    @Override
    public void act() { super.rest(); System.out.println(name + " studies"); }
    public void subject() { System.out.println("subject: Java"); }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String name = sc.next();
        int age = sc.nextInt();
        Sim sim;
        if (age <= 12) sim = new ChildSim(name);
        else sim = new YoungSim(name);
        sim.act();
        // 실제 타입을 확인한 후 다운캐스팅합니다.
        // Downcast only after checking the actual type.
        if (sim instanceof ChildSim) {
            ChildSim child = (ChildSim) sim;
            child.toy();
        } else if (sim instanceof YoungSim) {
            YoungSim young = (YoungSim) sim;
            young.subject();
        }
        sc.close();
    }
}
