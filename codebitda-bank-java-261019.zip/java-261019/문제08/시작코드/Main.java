import java.util.Scanner;

// TODO: 추상 클래스 Sim(생성자, 일반 메소드 rest, 추상 메소드 act)을 작성하세요.
// TODO: Write abstract Sim with a constructor, concrete rest(), and abstract act().
// TODO: ChildSim과 YoungSim에서 act()를 구현하고 전용 메소드를 작성하세요.
// TODO: Implement act() and the specific methods in ChildSim and YoungSim.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 이름·나이를 읽고 업캐스팅하세요. act() 호출 후 instanceof 확인과 다운캐스팅으로 전용 메소드를 호출하세요.
        // TODO: Read name and age, upcast, call act(), then check instanceof and downcast to call the specific method.
        
        sc.close();
    }
}
