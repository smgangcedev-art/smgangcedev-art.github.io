import java.util.Scanner;

// TODO: private width/height, 두 생성자, getArea()를 가진 Rectangle을 작성하세요.
// TODO: Write Rectangle with private width/height, two constructors, and getArea().

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 가로·세로를 읽고 두 객체의 면적을 출력하세요.
        // TODO: Read width and height and print the areas of both objects.
        
        sc.close();
    }
}
