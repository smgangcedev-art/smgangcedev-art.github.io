import java.util.Scanner;

class Rectangle {
    private int width, height;
    // 다른 생성자에 초기화를 맡깁니다.
    // Delegate initialization to the other constructor.
    public Rectangle() { this(1, 1); }
    public Rectangle(int width, int height) { this.width = width; this.height = height; }
    public int getArea() { return width * height; }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int w = sc.nextInt(), h = sc.nextInt();
        Rectangle a = new Rectangle();
        Rectangle b = new Rectangle(w, h);
        System.out.println("default: " + a.getArea());
        System.out.println("custom: " + b.getArea());
        sc.close();
    }
}
