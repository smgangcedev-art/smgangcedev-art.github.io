import java.util.Scanner;

// TODO: private name, 생성자, getName/getLength/getInitial을 가진 NameCard를 작성하세요.
// TODO: Write NameCard with private name, a constructor, and getName/getLength/getInitial.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 이름을 읽고 NameCard 객체의 메소드 결과를 출력하세요.
        // TODO: Read a name and print the results of the NameCard methods.
        
        sc.close();
    }
}
