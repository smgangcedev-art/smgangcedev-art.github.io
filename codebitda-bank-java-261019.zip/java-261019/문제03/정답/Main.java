import java.util.Scanner;

class NameCard {
    private String name;
    // 생성자로 객체의 필드를 초기화합니다.
    // Initialize the object field with the constructor.
    public NameCard(String name) { this.name = name; }
    public String getName() { return name; }
    public int getLength() { return name.length(); }
    public char getInitial() { return name.charAt(0); }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NameCard card = new NameCard(sc.next());
        System.out.println("name: " + card.getName());
        System.out.println("length: " + card.getLength());
        System.out.println("initial: " + card.getInitial());
        sc.close();
    }
}
