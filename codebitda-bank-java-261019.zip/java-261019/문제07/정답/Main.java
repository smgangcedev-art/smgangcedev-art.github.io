import java.util.Scanner;

class Sim {
    protected String name;
    public Sim(String name) { this.name = name; }
    public void act() { System.out.println(name + " rests"); }
}
class YoungSim extends Sim {
    public YoungSim(String name) { super(name); }
    // 실제 객체가 YoungSim이면 이 메소드가 실행됩니다.
    // This override runs when the actual object is a YoungSim.
    @Override
    public void act() { System.out.println(name + " studies"); }
}
class Reporter {
    // 인수의 선언 타입에 따라 오버로드가 선택됩니다.
    // The argument's declared type selects the overload.
    public void report(Sim s) { System.out.println("type: Sim"); }
    public void report(YoungSim s) { System.out.println("type: YoungSim"); }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        YoungSim young = new YoungSim(sc.next());
        Sim sim = young;
        Reporter reporter = new Reporter();
        reporter.report(sim);
        sim.act();
        reporter.report(young);
        young.act();
        sc.close();
    }
}
