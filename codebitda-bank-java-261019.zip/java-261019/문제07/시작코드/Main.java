import java.util.Scanner;

// TODO: Sim, YoungSim, Reporter를 문제 조건대로 작성하세요. 아래 main은 수정하지 마세요.
// TODO: Implement Sim, YoungSim, and Reporter as specified. Keep main unchanged.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        YoungSim young = new YoungSim(sc.next());
        Sim sim = young;
        Reporter reporter = new Reporter();
        reporter.report(sim);
        sim.act();
        reporter.report(young);
        young.act();
        sc.close();
    }
}
