import java.util.Scanner;

// TODO: Integer 필드 value와 생성자/getValue/addBonus를 가진 ScoreBox를 작성하세요.
// TODO: Write ScoreBox with Integer value, a constructor, getValue, and addBonus.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 문자열과 보너스를 읽고 try/catch/finally로 변환, 출력, 오류 처리를 작성하세요.
        // TODO: Read a token and bonus, then use try/catch/finally for conversion, output, and errors.
        
        sc.close();
    }
}
