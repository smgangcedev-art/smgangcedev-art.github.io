import java.util.Scanner;

class ScoreBox {
    private Integer value;
    // int를 Integer로 자동 박싱합니다.
    // Autobox int into Integer.
    public ScoreBox(int value) { this.value = value; }
    public int getValue() { return value; }
    // 계산에서 언박싱하고 반환할 때 박싱합니다.
    // Unbox for addition and box the returned result.
    public Integer addBonus(int bonus) { return value + bonus; }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String text = sc.next();
        int bonus = sc.nextInt();
        try {
            ScoreBox box = new ScoreBox(Integer.parseInt(text));
            System.out.println("score: " + box.getValue());
            System.out.println("bonus: " + box.addBonus(bonus));
        } catch (NumberFormatException e) {
            System.out.println("invalid");
        } finally {
            System.out.println("done");
        }
        sc.close();
    }
}
