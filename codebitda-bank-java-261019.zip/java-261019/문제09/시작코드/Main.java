import java.util.Scanner;

// TODO: MAX/charge/getLevel을 가진 Chargeable과 이를 구현한 Battery를 작성하세요.
// TODO: Write Chargeable with MAX/charge/getLevel and implement it in Battery.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 세 정수를 읽고 Chargeable 변수로 두 번 충전하며 출력하세요.
        // TODO: Read three integers and use a Chargeable variable to charge twice and print the levels.
        
        sc.close();
    }
}
