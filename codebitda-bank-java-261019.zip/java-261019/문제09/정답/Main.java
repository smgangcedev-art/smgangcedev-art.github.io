import java.util.Scanner;

interface Chargeable {
    // 인터페이스 상수는 모든 구현 객체가 공유합니다.
    // The interface constant is shared by all implementations.
    int MAX = 100;
    void charge(int amount);
    int getLevel();
}
class Battery implements Chargeable {
    private int level;
    public Battery(int level) { this.level = level; }
    @Override
    public void charge(int amount) {
        level += amount;
        if (level > Chargeable.MAX) level = Chargeable.MAX;
    }
    @Override
    public int getLevel() { return level; }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int initial = sc.nextInt(), a = sc.nextInt(), b = sc.nextInt();
        Chargeable battery = new Battery(initial);
        battery.charge(a);
        System.out.println("level: " + battery.getLevel());
        battery.charge(b);
        System.out.println("level: " + battery.getLevel());
        sc.close();
    }
}
