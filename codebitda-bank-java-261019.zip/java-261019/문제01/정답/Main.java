import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int minutes = sc.nextInt();
        // 정수 나눗셈과 나머지를 사용합니다.
        // Use integer division and remainder.
        System.out.println("hours: " + minutes / 60);
        System.out.println("minutes: " + minutes % 60);
        sc.close();
    }
}
