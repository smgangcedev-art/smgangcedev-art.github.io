import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 정수를 읽고 hours: 와 minutes: 형식으로 계산 결과를 출력하세요.
        // TODO: Read an integer and print the results with hours: and minutes: labels.
        
        sc.close();
    }
}
