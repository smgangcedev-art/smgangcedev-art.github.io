import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int count = 0, sum = 0;
        // 짝수만 세고 더합니다.
        // Count and add only even numbers.
        for (int i = 1; i <= n; i++) {
            if (i % 2 == 0) { count++; sum += i; }
        }
        System.out.println("count: " + count);
        System.out.println("sum: " + sum);
        sc.close();
    }
}
