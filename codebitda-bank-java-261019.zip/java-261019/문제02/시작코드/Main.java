import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: n을 읽고 1~n의 짝수 개수와 합을 출력하세요.
        // TODO: Read n and print the count and sum of even numbers from 1 to n.
        
        sc.close();
    }
}
