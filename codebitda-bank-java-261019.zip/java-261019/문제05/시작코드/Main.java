import java.util.Scanner;

// TODO: private balance, 생성자, deposit/withdraw/getBalance를 가진 Wallet을 작성하세요.
// TODO: Write Wallet with private balance, a constructor, and deposit/withdraw/getBalance.

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // TODO: 초기 잔액과 명령 수를 읽으세요. 명령마다 equals()로 구분하고 처리 결과를 출력하세요.
        // TODO: Read the initial balance and command count. Use equals() to dispatch each command and print its result.
        
        sc.close();
    }
}
