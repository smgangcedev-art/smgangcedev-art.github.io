import java.util.Scanner;

class Wallet {
    private int balance;
    public Wallet(int balance) { this.balance = balance; }
    public int getBalance() { return balance; }
    public void deposit(int amount) { balance += amount; }
    public boolean withdraw(int amount) {
        // 실패하면 잔액을 변경하지 않습니다.
        // Leave the balance unchanged on failure.
        if (balance < amount) return false;
        balance -= amount;
        return true;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Wallet wallet = new Wallet(sc.nextInt());
        int n = sc.nextInt();
        for (int i = 0; i < n; i++) {
            String command = sc.next();
            int amount = sc.nextInt();
            boolean ok;
            if (command.equals("deposit")) { wallet.deposit(amount); ok = true; }
            else { ok = wallet.withdraw(amount); }
            System.out.println((ok ? "OK " : "FAIL ") + wallet.getBalance());
        }
        sc.close();
    }
}
