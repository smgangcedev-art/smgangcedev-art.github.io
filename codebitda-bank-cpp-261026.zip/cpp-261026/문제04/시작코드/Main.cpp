#include <iostream>
using namespace std;

// TODO: 포인터로 탐색하여 첫 번째 최댓값 원소를 참조로 반환하는 findMax 함수 전체를 정의하세요.
// Define findMax to return a reference to the first maximum element using pointer traversal.

int main() {
    int a[5];

    cout << "정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];

    // TODO: 함수를 호출하고 반환된 참조를 이용해 원본 최댓값 원소에 10을 더하세요.
    // Call the function and use the returned reference to add 10 to the original maximum element.

    for (int i = 0; i < 5; ++i) cout << (i ? " " : "") << a[i];
    cout << '\n';

    return 0;
}
