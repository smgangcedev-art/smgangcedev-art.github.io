// 정답 / Answer: 4. 참조 리턴으로 최댓값 원소 수정
// Modify the Maximum Element Through a Returned Reference
// 풀이: 첫 최댓값의 참조를 반환하여 원본에 10을 더합니다.
// Solution: Return a reference to the first maximum and add 10 to the original element.

#include <iostream>
using namespace std;

int& findMax(int* p, int size) {
    int* best = p;
    for (int i = 1; i < size; ++i)
        if (*(p + i) > *best) best = p + i;
    return *best;
}
int main() {
    int a[5];

    cout << "정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];

    findMax(a, 5) += 10;
    for (int i = 0; i < 5; ++i) cout << (i ? " " : "") << a[i];
    cout << '\n';

    return 0;
}
