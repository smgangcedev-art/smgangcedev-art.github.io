#include <iostream>
using namespace std;

class GameSave {
private:
    int* gold;
public:
    GameSave();
    GameSave(int amount);
    GameSave(GameSave& other);
    ~GameSave();
    void setGold(int amount) { *gold = amount; }
    int getGold() { return *gold; }
    void buyItem(int price) { *gold -= price; }
};

// TODO: 기본 생성자를 정의하세요. GameSave(0)에 위임하세요.
// Define the default constructor by delegating to GameSave(0).

GameSave::GameSave(int amount) {
    gold = new int(amount);
    cout << "생성했습니다." << '\n';
}

GameSave::GameSave(GameSave& other) {

    // TODO: 새 정수 공간을 할당한 뒤 원본의 골드 값을 복사하고, 생성했습니다.를 출력하세요.
    // Allocate a new integer, copy the original gold value, and print exactly "생성했습니다." on its own line.

}

GameSave::~GameSave() {

    // TODO: 이 객체가 소유한 정수 공간을 해제하세요.
    // Release the integer owned by this object.

    // TODO: 소멸했습니다.를 한 줄 출력하세요.
    // Print exactly "소멸했습니다." on its own line.

}

int main() {
    int amount, price;

    cout << "저장된 골드와 회복 물약 가격을 입력하세요 (예: 100 30):" << '\n';
    cin >> amount >> price;

    // 저장 슬롯 1의 데이터를 준비합니다.
    // Prepare the data in save slot 1.
    cout << "[저장 슬롯 1 불러오기]" << '\n';
    GameSave original;
    original.setGold(amount);
    cout << "저장된 골드: " << original.getGold() << '\n';

    cout << "[이어하기]" << '\n';
    {
        // 저장 데이터의 복사본으로 플레이합니다.
        // Play using a copy of the saved data.
        GameSave playing(original);
        cout << "모험을 시작합니다. 보유 골드: " << playing.getGold() << '\n';
        cout << "[상점] 회복 물약 1개 구매: " << price << "골드" << '\n';
        playing.buyItem(price);
        cout << "현재 골드: " << playing.getGold() << '\n';
        cout << "저장 슬롯 1의 골드: " << original.getGold() << '\n';
        cout << "[저장하지 않고 타이틀로 돌아가기]" << '\n';
    } // 복사본만 소멸 / Only the copy is destroyed here.

    // 플레이가 끝나도 저장 슬롯은 그대로 남아 있습니다.
    // The save slot remains unchanged after the play session ends.
    cout << "[저장 슬롯 1 다시 확인]" << '\n';
    cout << "저장된 골드: " << original.getGold() << '\n';
    cout << "[게임 종료]" << '\n';

    return 0;
}
