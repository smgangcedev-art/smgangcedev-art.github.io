// 정답 / Answer: 9. 게임 저장 데이터 복사 — 원본을 지켜라
// Copy a Game Save — Protect the Original
// 풀이: 깊은 복사로 원본과 복사본의 골드 저장 공간을 분리합니다.
// Solution: Use a deep copy so the original and copied gold occupy separate storage.

#include <iostream>
using namespace std;

class GameSave {
private:
    int* gold;
public:
    GameSave();
    GameSave(int amount);
    GameSave(GameSave& other);
    ~GameSave();
    void setGold(int amount) { *gold = amount; }
    int getGold() { return *gold; }
    void buyItem(int price) { *gold -= price; }
};

GameSave::GameSave() : GameSave(0) {}

GameSave::GameSave(int amount) {
    gold = new int(amount);
    cout << "생성했습니다." << '\n';
}

GameSave::GameSave(GameSave& other) {
    gold = new int(*other.gold);
    cout << "생성했습니다." << '\n';
}

GameSave::~GameSave() {
    delete gold;
    cout << "소멸했습니다." << '\n';
}

int main() {
    int amount, price;

    cout << "저장된 골드와 회복 물약 가격을 입력하세요 (예: 100 30):" << '\n';
    cin >> amount >> price;

    // 저장 슬롯 1의 데이터를 준비합니다.
    // Prepare the data in save slot 1.
    cout << "[저장 슬롯 1 불러오기]" << '\n';
    GameSave original;
    original.setGold(amount);
    cout << "저장된 골드: " << original.getGold() << '\n';

    cout << "[이어하기]" << '\n';
    {
        // 저장 데이터의 복사본으로 플레이합니다.
        // Play using a copy of the saved data.
        GameSave playing(original);
        cout << "모험을 시작합니다. 보유 골드: " << playing.getGold() << '\n';
        cout << "[상점] 회복 물약 1개 구매: " << price << "골드" << '\n';
        playing.buyItem(price);
        cout << "현재 골드: " << playing.getGold() << '\n';
        cout << "저장 슬롯 1의 골드: " << original.getGold() << '\n';
        cout << "[저장하지 않고 타이틀로 돌아가기]" << '\n';
    } // 복사본만 소멸 / Only the copy is destroyed here.

    // 플레이가 끝나도 저장 슬롯은 그대로 남아 있습니다.
    // The save slot remains unchanged after the play session ends.
    cout << "[저장 슬롯 1 다시 확인]" << '\n';
    cout << "저장된 골드: " << original.getGold() << '\n';
    cout << "[게임 종료]" << '\n';

    return 0;
}
