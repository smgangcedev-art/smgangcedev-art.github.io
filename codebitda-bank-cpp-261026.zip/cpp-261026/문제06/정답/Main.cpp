// 정답 / Answer: 6. 동적 배열을 제자리에서 뒤집기
// Reverse a Dynamic Array in Place
// 풀이: 동적 배열의 양 끝을 교환한 뒤 메모리를 해제합니다.
// Solution: Swap opposite ends of the dynamic array, then release its memory.

#include <iostream>
using namespace std;

void reverseArray(int* p, int size) {
    int* left = p;
    int* right = p + size - 1;
    while (left < right) {
        int temp = *left;
        *left = *right;
        *right = temp;
        ++left;
        --right;
    }
}
int main() {
    int n;
    int* p = nullptr;

    cout << "원소 수 n을 입력하세요 (1~20):" << '\n';
    cin >> n;
    p = new int[n];
    cout << "뒤집을 정수 n개를 입력하세요:" << '\n';
    for (int i = 0; i < n; ++i) cin >> *(p + i);

    reverseArray(p, n);
    for (int i = 0; i < n; ++i) cout << (i ? " " : "") << *(p + i);
    cout << '\n';
    delete[] p;

    return 0;
}
