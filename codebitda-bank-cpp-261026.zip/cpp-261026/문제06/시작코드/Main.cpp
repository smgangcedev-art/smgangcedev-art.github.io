#include <iostream>
using namespace std;

void reverseArray(int* p, int size) {

    // TODO: 두 포인터로 양 끝의 값을 교환하며 이동하세요.
    // Swap the end values and move both pointers inward.

}
int main() {
    int n;
    int* p = nullptr;

    cout << "원소 수 n을 입력하세요 (1~20):" << '\n';
    cin >> n;

    // TODO: p에 크기가 n인 동적 배열의 주소를 저장하세요. p를 다시 선언하지 마세요.
    // Allocate an array of size n and assign its address to p without redeclaring p.

    cout << "뒤집을 정수 n개를 입력하세요:" << '\n';
    for (int i = 0; i < n; ++i) cin >> *(p + i);

    reverseArray(p, n);
    for (int i = 0; i < n; ++i) cout << (i ? " " : "") << *(p + i);
    cout << '\n';

    // TODO: 배열 메모리를 해제하세요.
    // Release the array memory.

    return 0;
}
