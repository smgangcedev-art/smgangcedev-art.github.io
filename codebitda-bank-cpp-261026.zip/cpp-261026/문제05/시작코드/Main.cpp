#include <iostream>
using namespace std;

class Battery {
private:
    int level;
public:
    Battery();
    ~Battery();
    Battery(int level);
    void charge(int amount);
    int getLevel();
};

// TODO: Battery의 기본 생성자를 정의하세요. 위임 생성자를 사용하여 기본값 0으로 초기화하세요.
// Define the default Battery constructor by delegating to Battery(0).

Battery::Battery(int level) {

    // TODO: "생성했습니다."를 한 줄 출력하세요.
    // Print exactly "생성했습니다." on its own line.

    // TODO: this를 사용해 멤버변수를 초기화하세요.
    // Initialize the member using this.

}
void Battery::charge(int amount) {

    // TODO: 충전 후 최댓값을 100으로 제한하세요.
    // Charge the battery and cap the level at 100.

}
int Battery::getLevel() { return level; }
Battery::~Battery() {

    // TODO: "소멸했습니다."를 한 줄 출력하세요.
    // Print exactly "소멸했습니다." on its own line.

}
int main() {
    int start, amount;
    Battery* p;

    cout << "초기 충전량과 추가 충전량을 입력하세요:" << '\n';
    cin >> start >> amount;

    Battery battery(start);

    // TODO: 제공된 포인터 p로 battery를 가리키고 충전한 뒤 값을 출력하세요.
    // Make the provided pointer p point to battery, charge it, and print the level.

    return 0;
}
