// 정답 / Answer: 5. 배터리를 객체 포인터로 충전
// Charge a Battery Through an Object Pointer
// 풀이: 객체 포인터로 충전하고 충전량을 100으로 제한합니다.
// Solution: Charge through an object pointer and cap the level at 100.

#include <iostream>
using namespace std;

class Battery {
private:
    int level;
public:
    Battery();
    ~Battery();
    Battery(int level);
    void charge(int amount);
    int getLevel();
};
Battery::Battery() : Battery(0) {}
Battery::Battery(int level) {
    cout << "생성했습니다." << '\n';
    this->level = level;
}
void Battery::charge(int amount) {
    level += amount;
    if (level > 100) level = 100;
}
int Battery::getLevel() { return level; }
Battery::~Battery() {
    cout << "소멸했습니다." << '\n';
}
int main() {
    int start, amount;
    Battery* p;

    cout << "초기 충전량과 추가 충전량을 입력하세요:" << '\n';
    cin >> start >> amount;

    Battery battery(start);
    p = &battery;
    p->charge(amount);
    cout << p->getLevel() << '\n';

    return 0;
}
