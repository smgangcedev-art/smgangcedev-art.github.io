#include <iostream>
using namespace std;

void swapValues(int* p, int* q) {
    int temp = *p;
    *p = *q;
    *q = temp;
}
void sortThree(int* p, int* q, int* r) {

    // TODO: 세 값을 비교하고 필요한 값을 교환하여 오름차순으로 정렬하세요.
    // Compare and swap values to arrange them in ascending order.

}
int main() {
    int a, b, c;

    cout << "정수 3개를 입력하세요:" << '\n';
    cin >> a >> b >> c;

    // TODO: 세 변수의 주소를 전달하여 정렬 함수를 호출하세요.
    // Call the sorting function with the addresses of all three variables.

    cout << a << ' ' << b << ' ' << c << '\n';

    return 0;
}
