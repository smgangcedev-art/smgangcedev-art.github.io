// 정답 / Answer: 1. 포인터로 세 값 정렬
// Sort Three Values Using Pointers
// 풀이: 포인터로 값을 비교하고 교환합니다.
// Solution: Compare and swap the values through pointers.

#include <iostream>
using namespace std;

void swapValues(int* p, int* q) {
    int temp = *p;
    *p = *q;
    *q = temp;
}
void sortThree(int* p, int* q, int* r) {
    if (*p > *q) swapValues(p, q);
    if (*p > *r) swapValues(p, r);
    if (*q > *r) swapValues(q, r);
}
int main() {
    int a, b, c;

    cout << "정수 3개를 입력하세요:" << '\n';
    cin >> a >> b >> c;

    sortThree(&a, &b, &c);
    cout << a << ' ' << b << ' ' << c << '\n';

    return 0;
}
