#include <iostream>
using namespace std;

class Device {
private:
    int id;
    static int active;
public:
    Device();
    Device(int id);
    ~Device();
    int getId();
    static int getActive();
};
int Device::active = 0;

// TODO: Device의 기본 생성자를 정의하세요. 위임 생성자를 사용하여 기본값 0으로 초기화하세요.
// Define the default Device constructor by delegating to Device(0).

Device::Device(int id) {

    // TODO: "생성했습니다."를 한 줄 출력하세요.
    // Print exactly "생성했습니다." on its own line.

    // TODO: 번호를 저장하고 현재 객체 수를 증가시키세요.
    // Store the ID and increment the active count.

}
Device::~Device() {

    // TODO: "소멸했습니다."를 한 줄 출력하세요.
    // Print exactly "소멸했습니다." on its own line.

    // TODO: 현재 객체 수를 감소시키세요.
    // Decrement the active count.

}
int Device::getId() { return id; }
int Device::getActive() { return active; }
int main() {
    int n, k;
    Device** slots = nullptr;

    cout << "대여할 기기 수 n을 입력하세요 (1~20):" << '\n';
    cin >> n;

    // TODO: Device 포인터 n개를 저장할 배열을 동적으로 할당하세요.
    // Dynamically allocate an array for n Device pointers.

    for (int i = 0; i < n; ++i) {
        int id;
        cout << "기기 번호를 입력하세요 (1~999, 중복 없이):" << '\n';
        cin >> id;

        // TODO: 입력한 번호로 Device 객체를 동적으로 생성하여 저장하세요.
        // Dynamically create a Device with the input ID and store its pointer.

    }
    cout << "반납할 기기의 인덱스를 입력하세요 (0부터 n-1까지):" << '\n';
    cin >> k;
    cout << Device::getActive() << '\n';
    cout << slots[k]->getId() << '\n';

    // TODO: 선택한 객체를 삭제하고 포인터를 초기화하세요.
    // Delete the selected object and clear its pointer.

    cout << Device::getActive() << '\n';

    // TODO: 남은 객체와 포인터 배열을 모두 해제하세요. nullptr 삭제는 안전합니다.
    // Delete the remaining objects and release the pointer array; deleting nullptr is safe.

    cout << Device::getActive() << '\n';

    return 0;
}
