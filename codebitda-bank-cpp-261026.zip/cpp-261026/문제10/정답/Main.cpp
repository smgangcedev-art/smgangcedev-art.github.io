// 정답 / Answer: 10. 원하는 개수만큼 기기 대여하기
// Rent a User-Specified Number of Devices
// 풀이: 기기 객체와 포인터 배열을 동적으로 할당하고 각각 해제합니다.
// Solution: Dynamically allocate the device objects and pointer array, then release both correctly.

#include <iostream>
using namespace std;

class Device {
private:
    int id;
    static int active;
public:
    Device();
    Device(int id);
    ~Device();
    int getId();
    static int getActive();
};
int Device::active = 0;
Device::Device() : Device(0) {}
Device::Device(int id) {
    cout << "생성했습니다." << '\n';
    this->id = id;
    ++active;
}
Device::~Device() {
    cout << "소멸했습니다." << '\n';
    --active;
}
int Device::getId() { return id; }
int Device::getActive() { return active; }
int main() {
    int n, k;
    Device** slots = nullptr;

    cout << "대여할 기기 수 n을 입력하세요 (1~20):" << '\n';
    cin >> n;

    slots = new Device*[n]();
    for (int i = 0; i < n; ++i) {
        int id;
        cout << "기기 번호를 입력하세요 (1~999, 중복 없이):" << '\n';
        cin >> id;
        slots[i] = new Device(id);
    }
    cout << "반납할 기기의 인덱스를 입력하세요 (0부터 n-1까지):" << '\n';
    cin >> k;
    cout << Device::getActive() << '\n';
    cout << slots[k]->getId() << '\n';
    delete slots[k];
    slots[k] = nullptr;
    cout << Device::getActive() << '\n';
    for (int i = 0; i < n; ++i) delete slots[i];
    delete[] slots;
    cout << Device::getActive() << '\n';

    return 0;
}
