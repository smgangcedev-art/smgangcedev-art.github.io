// 정답 / Answer: 8. 게임 점수 계산 함수 오버로딩
// Overload Functions for Individual and Team Scores
// 풀이: 오버로딩으로 개인 점수와 최저 점수 하나를 제외한 팀 점수를 계산합니다.
// Solution: Use overloads for the individual score and the team total excluding one minimum.

#include <iostream>
using namespace std;

int calculateScore(int score, int bonus = 10) {
    return score + bonus;
}

int calculateScore(int* p, int size) {
    int total = 0;
    int lowest = *p;
    for (int i = 0; i < size; ++i) {
        int score = *(p + i);
        total += score;
        if (score < lowest) lowest = score;
    }
    return total - lowest;
}

int main() {
    int personal, team[4];
    int personalResult = 0, teamResult = 0;

    cout << "개인 점수를 입력하세요:" << '\n';
    cin >> personal;
    cout << "팀원 4명의 점수를 입력하세요:" << '\n';
    for (int i = 0; i < 4; ++i) cin >> team[i];

    personalResult = calculateScore(personal);
    teamResult = calculateScore(team, 4);

    cout << personalResult << '\n';
    cout << teamResult << '\n';

    return 0;
}
