#include <iostream>
using namespace std;

// TODO: 개인 점수를 계산하는 calculateScore 함수 전체를 작성하세요. 보너스 기본값은 10입니다.
// Write the complete personal-score function with a default bonus of 10.

// TODO: 포인터로 팀 점수를 계산하는 calculateScore 함수 전체를 작성하세요. 최저 점수 하나만 제외합니다.
// Write the complete team-score overload using a pointer; exclude exactly one lowest score.

int main() {
    int personal, team[4];
    int personalResult = 0, teamResult = 0;

    cout << "개인 점수를 입력하세요:" << '\n';
    cin >> personal;
    cout << "팀원 4명의 점수를 입력하세요:" << '\n';
    for (int i = 0; i < 4; ++i) cin >> team[i];

    // TODO: 두 함수를 호출하여 personalResult와 teamResult에 저장하세요. 개인 보너스는 기본값을 사용하세요.
    // Call the two overloads and store their results in personalResult and teamResult; use the default bonus for the individual score.

    cout << personalResult << '\n';
    cout << teamResult << '\n';

    return 0;
}
