// 정답 / Answer: 7. 도서 정보 조회
// Look Up Book Information
// 풀이: 객체 포인터로 가격 조건을 만족하는 책을 조회합니다.
// Solution: Use object pointers to find books satisfying the price limit.

#include <iostream>
using namespace std;

#include <string>

class Book {
private:
    string title;
    int price;
public:
    Book();
    ~Book();
    Book(string title, int price);
    string getTitle();
    int getPrice();
};
Book::Book() : Book("", 0) {}
Book::Book(string title, int price) : title(title), price(price) {
    cout << "생성했습니다." << '\n';
}
string Book::getTitle() { return title; }
int Book::getPrice() { return price; }
void showAffordable(Book* p, int size, int limit) {
    bool found = false;
    for (int i = 0; i < size; ++i) {
        if ((p + i)->getPrice() <= limit) {
            cout << (p + i)->getTitle() << '\n';
            found = true;
        }
    }
    if (!found) cout << "NONE" << '\n';
}
Book::~Book() {
    cout << "소멸했습니다." << '\n';
}
int main() {
    string titles[3];
    int prices[3], limit;

    cout << "책 3권의 제목과 가격을 한 권씩 입력하세요 (예: Cpp 15000):" << '\n';
    for (int i = 0; i < 3; ++i) cin >> titles[i] >> prices[i];
    cout << "조회할 기준 가격을 입력하세요:" << '\n';
    cin >> limit;

    Book books[3] = {Book(titles[0], prices[0]), Book(titles[1], prices[1]), Book(titles[2], prices[2])};
    showAffordable(books, 3, limit);

    return 0;
}
