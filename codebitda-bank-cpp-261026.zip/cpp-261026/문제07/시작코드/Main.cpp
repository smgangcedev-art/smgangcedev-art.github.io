#include <iostream>
using namespace std;

#include <string>

class Book {
private:
    string title;
    int price;
public:
    Book();
    ~Book();
    Book(string title, int price);
    string getTitle();
    int getPrice();
};

// TODO: Book의 기본 생성자를 정의하세요. 위임 생성자를 사용하여 기본값 "", 0으로 초기화하세요.
// Define the default Book constructor by delegating to Book("", 0).

Book::Book(string title, int price) : title(title), price(price) {

    // TODO: "생성했습니다."를 한 줄 출력하세요.
    // Print exactly "생성했습니다." on its own line.

}
string Book::getTitle() { return title; }
int Book::getPrice() { return price; }
void showAffordable(Book* p, int size, int limit) {

    // TODO: 객체 포인터로 조건에 맞는 책의 제목을 출력하세요. 없으면 NONE을 출력하세요.
    // Use object pointers to print matching titles, or NONE if no book matches.

}
Book::~Book() {

    // TODO: "소멸했습니다."를 한 줄 출력하세요.
    // Print exactly "소멸했습니다." on its own line.

}
int main() {
    string titles[3];
    int prices[3], limit;

    cout << "책 3권의 제목과 가격을 한 권씩 입력하세요 (예: Cpp 15000):" << '\n';
    for (int i = 0; i < 3; ++i) cin >> titles[i] >> prices[i];
    cout << "조회할 기준 가격을 입력하세요:" << '\n';
    cin >> limit;

    Book books[3] = {Book(titles[0], prices[0]), Book(titles[1], prices[1]), Book(titles[2], prices[2])};
    showAffordable(books, 3, limit);

    return 0;
}
