#include <iostream>
using namespace std;

// TODO: 포인터 매개변수와 포인터 연산을 사용하여 합계를 반환하는 sumArray 함수 전체를 정의하세요.
// Define the complete sumArray function using a pointer parameter and pointer arithmetic to return the sum.

int main() {
    int a[5];

    cout << "합계를 구할 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << sumArray(a, 5) << '\n';

    return 0;
}
