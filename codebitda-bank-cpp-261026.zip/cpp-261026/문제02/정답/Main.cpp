// 정답 / Answer: 2. 포인터로 배열 합계
// Sum an Array Using Pointers
// 풀이: 포인터 연산으로 배열 합계를 구합니다.
// Solution: Use pointer arithmetic to sum the array elements.

#include <iostream>
using namespace std;

int sumArray(int* p, int size) {
    int sum = 0;
    for (int i = 0; i < size; ++i) sum += *(p + i);
    return sum;
}
int main() {
    int a[5];

    cout << "합계를 구할 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << sumArray(a, 5) << '\n';

    return 0;
}
