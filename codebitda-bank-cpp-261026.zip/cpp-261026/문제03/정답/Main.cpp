// 정답 / Answer: 3. 배열의 일치 여부와 다른 개수 구하기
// Compare Two Arrays and Count Mismatches
// 풀이: 일치 여부를 반환하고 참조로 불일치 개수를 전달합니다.
// Solution: Return equality and report the mismatch count through a reference.

#include <iostream>
using namespace std;

bool equalArray(int* p, int* q, int& differentCount) {
    differentCount = 0;
    for (int i = 0; i < 5; ++i) {
        if (*(p + i) != *(q + i)) ++differentCount;
    }
    return differentCount == 0;
}
int main() {
    int a[5], b[5];
    int differentCount = 0;
    bool same;

    cout << "첫 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << "두 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> b[i];

    same = equalArray(a, b, differentCount);
    cout << (same ? "SAME" : "DIFFERENT") << '\n';
    cout << differentCount << '\n';

    return 0;
}
