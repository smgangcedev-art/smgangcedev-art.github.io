#include <iostream>
using namespace std;

// TODO: 포인터 2개와 참조 1개를 받는 함수 전체를 정의하세요. 일치 여부는 반환하고, 다른 위치의 개수는 참조로 전달하세요.
// Define the function with two pointers and one reference. Return whether the arrays are equal and pass the mismatch count through the reference.

int main() {
    int a[5], b[5];
    int differentCount = 0;
    bool same;

    cout << "첫 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> a[i];
    cout << "두 번째 배열의 정수 5개를 입력하세요:" << '\n';
    for (int i = 0; i < 5; ++i) cin >> b[i];

    same = equalArray(a, b, differentCount);
    cout << (same ? "SAME" : "DIFFERENT") << '\n';
    cout << differentCount << '\n';

    return 0;
}
