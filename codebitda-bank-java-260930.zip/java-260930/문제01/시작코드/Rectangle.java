import java.util.Scanner;
import java.util.InputMismatchException;

public class Rectangle {
    // 가로와 세로를 저장합니다.
    // Store the width and height.
    int width;
    int height;

    // TODO: 두 필드를 1로 초기화하는 기본 생성자를 작성하세요.
    // TODO: Write a no-argument constructor that sets both fields to 1.

    // TODO: w, h로 필드를 초기화하는 Rectangle(int w, int h)를 작성하세요.
    // TODO: Write Rectangle(int w, int h) to initialize the fields with w and h.

    // TODO: 가로와 세로의 곱을 반환하는 int getArea()를 작성하세요.
    // TODO: Write int getArea() to return width times height.

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 3번을 선택할 때까지 반복합니다.
        // Repeat until option 3 is selected.
        while (true) {
            System.out.println("menu: 1-auto 2-input 3-exit");
            int menu = sc.nextInt();
            sc.nextLine();

            if (menu == 1) {
                // 기본 생성자로 매번 새 객체를 만듭니다.
                // Create a new object with the no-argument constructor each time.
                Rectangle rect = new Rectangle();
                System.out.println("area: " + rect.getArea());
            } else if (menu == 2) {
                System.out.println("width height:");

                // TODO: try에서 두 정수를 읽고 new Rectangle(w, h)로 새 객체를 만드세요.
                // TODO: In try, read two integers and create a new object with new Rectangle(w, h).
                // 면적은 "area: " 뒤에 출력하세요.
                // Print the area after "area: ".

                // TODO: catch (InputMismatchException e)에서 "error: enter integers"를 출력하세요.
                // TODO: In catch (InputMismatchException e), print "error: enter integers".

                // TODO: finally에서 sc.nextLine()으로 남은 줄을 비우고 "done"을 출력하세요.
                // TODO: In finally, call sc.nextLine() to discard the rest of the line, then print "done".

            } else if (menu == 3) {
                System.out.println("bye");
                // TODO: 반복문을 종료하세요.
                // TODO: Exit the loop.
            }
        }
    }
}
