import java.util.Scanner;
import java.util.InputMismatchException;

public class Rectangle {
    // 가로와 세로를 저장하는 필드입니다.
    // These fields store the width and height.
    int width;
    int height;

    public Rectangle() {
        // 자동 생성 시 가로와 세로를 1로 초기화합니다.
        // Initialize both dimensions to 1 for automatic creation.
        width = 1;
        height = 1;
    }

    public Rectangle(int w, int h) {
        // 입력받은 값으로 필드를 초기화합니다.
        // Initialize the fields with the supplied values.
        width = w;
        height = h;
    }

    public int getArea() {
        return width * height;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 3번을 선택할 때까지 메뉴를 반복합니다.
        // Repeat the menu until option 3 is selected.
        while (true) {
            System.out.println("menu: 1-auto 2-input 3-exit");
            int menu = sc.nextInt();
            sc.nextLine();

            if (menu == 1) {
                // 매번 새 객체를 만들며 기본 생성자를 호출합니다.
                // Create a new object and call its no-argument constructor each time.
                Rectangle rect = new Rectangle();
                System.out.println("area: " + rect.getArea());
            } else if (menu == 2) {
                System.out.println("width height:");
                try {
                    // 두 정수를 읽은 뒤 새 객체의 생성자에 전달합니다.
                    // Read two integers, then pass them to a new object's constructor.
                    int w = sc.nextInt();
                    int h = sc.nextInt();
                    Rectangle rect = new Rectangle(w, h);
                    System.out.println("area: " + rect.getArea());
                } catch (InputMismatchException e) {
                    // 문자 입력 오류를 처리합니다.
                    // Handle non-integer input.
                    System.out.println("error: enter integers");
                } finally {
                    // 남은 입력 줄을 비워 다음 메뉴를 정상적으로 읽습니다.
                    // Discard the rest of the line before reading the next menu choice.
                    sc.nextLine();
                    System.out.println("done");
                }
            } else if (menu == 3) {
                System.out.println("bye");
                break;
            }
        }
    }
}
