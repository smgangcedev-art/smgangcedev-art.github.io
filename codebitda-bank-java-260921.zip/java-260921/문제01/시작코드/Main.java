import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String userId; // user ID

        boolean hasDigit = false;
        // 힌트: userId.length(), userId.charAt(i), Character.isDigit(...)
        // TODO: 문자열에 숫자가 있는지 확인하세요.

        System.out.println("길이: " + userId.length());
        // TODO: if 문으로 사용 가능 여부를 출력하세요.
    }
}