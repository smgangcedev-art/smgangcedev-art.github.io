import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String userId = sc.nextLine().trim();

        boolean hasDigit = false;
        for (int i = 0; i < userId.length(); i++) {
            if (Character.isDigit(userId.charAt(i))) {
                hasDigit = true;
                break;
            }
        }

        System.out.println("길이: " + userId.length());
        if (userId.length() >= 8 && hasDigit) {
            System.out.println("판정: 사용 가능");
        } else {
            System.out.println("판정: 사용 불가");
        }
    }
}