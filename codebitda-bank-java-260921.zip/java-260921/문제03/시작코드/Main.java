import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int attempts = 0;
        boolean success = false;
        String password;

        // TODO: do-while 문으로 최대 3회 입력과 판정을 구현하세요.
        // 힌트: password.equals("open123")

        if (!success) {
            System.out.println("접근 차단");
        }
    }
}