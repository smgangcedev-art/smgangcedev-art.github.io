import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int attempts = 0;
        boolean success = false;
        String password;

        do {
            password = sc.nextLine();
            attempts++;
            success = password.equals("open123");
            System.out.println(attempts + "회: " + (success ? "성공" : "실패"));
        } while (!success && attempts < 3);

        if (!success) {
            System.out.println("접근 차단");
        }
    }
}