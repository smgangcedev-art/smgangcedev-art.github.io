import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String text = sc.nextLine().toLowerCase();
        int vowelCount = 0; // 모음 개수 
        int digitCount = 0; // 자음 개수

        // 힌트: text.length(), text.charAt(i), "aeiou".indexOf(ch)
        // TODO: for 문으로 모음과 숫자의 개수를 세세요.

        System.out.println("모음 수: " + vowelCount);
        System.out.println("숫자 수: " + digitCount);
    }
}