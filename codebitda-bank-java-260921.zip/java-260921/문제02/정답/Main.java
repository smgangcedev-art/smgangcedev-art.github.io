import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String text = sc.nextLine().toLowerCase();
        int vowelCount = 0;
        int digitCount = 0;

        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if ("aeiou".indexOf(ch) >= 0) {
                vowelCount++;
            }
            if (Character.isDigit(ch)) {
                digitCount++;
            }
        }

        System.out.println("모음 수: " + vowelCount);
        System.out.println("숫자 수: " + digitCount);
    }
}