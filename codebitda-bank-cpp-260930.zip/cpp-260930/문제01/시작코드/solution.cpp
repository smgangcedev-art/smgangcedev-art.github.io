#include <iostream>
using namespace std;

// equalArray의 함수 프로토타입을 선언하세요.
// Declare the function prototype for equalArray.

// swapArray의 함수 프로토타입을 선언하세요.
// Declare the function prototype for swapArray.

int main() {
    int a[5];
    int b[5];

    // for 문과 cin으로 첫 번째 배열에 정수 5개를 입력받으세요.
    // Use the for loop and cin to read five integers into the first array.
    for (int i = 0; i < 5; i++) {
        // cin으로 a[i]에 정수를 입력받으세요.
        // Use cin to read an integer into a[i].
    }

    // for 문과 cin으로 두 번째 배열에 정수 5개를 입력받으세요.
    // Use the for loop and cin to read five integers into the second array.
    for (int i = 0; i < 5; i++) {
        // cin으로 b[i]에 정수를 입력받으세요.
        // Use cin to read an integer into b[i].
    }

    // if 문에서 equalArray를 호출하여 교환 전 비교 결과를 출력합니다.
    // Call equalArray in an if statement to print the result before swapping.
    if (equalArray(a, b, 5)) cout << "arrays equal" << "\n";
    else cout << "arrays not equal" << "\n";

    // 두 배열의 원소를 서로 교환합니다.
    // Swap the corresponding elements of the two arrays.
    swapArray(a, b, 5);

    // 교환 후 배열 a를 한 줄로 출력합니다.
    // Print array a on one line after swapping.
    for (int i = 0; i < 5; i++) {
        if (i > 0) cout << " ";
        cout << a[i];
    }
    cout << "\n";

    // 교환 후 배열 b를 한 줄로 출력합니다.
    // Print array b on one line after swapping.
    for (int i = 0; i < 5; i++) {
        if (i > 0) cout << " ";
        cout << b[i];
    }
    cout << "\n";

    return 0;
}

// equalArray를 구현하세요.
// Implement equalArray.
bool equalArray(int* p, int* q, int size) {
    // *(p + i)와 *(q + i)를 비교하여 true 또는 false를 반환하세요.
    // Compare *(p + i) with *(q + i) and return true or false.
}

// swapArray를 구현하세요.
// Implement swapArray.
void swapArray(int* p, int* q, int size) {
    // 새 배열을 만들지 말고, 포인터로 원소를 교환하세요.
    // Swap the elements through pointers without creating another array.
    int temp;
    // temp는 교환할 정수 값 하나를 잠시 보관하는 변수입니다.
    // temp temporarily holds one integer value during a swap.
}
