#include <iostream>
using namespace std;

// 두 함수의 프로토타입을 선언합니다.
// Declare the prototypes for both functions.
bool equalArray(int* p, int* q, int size);
void swapArray(int* p, int* q, int size);

int main() {
    int a[5];
    int b[5];

    // 첫 번째 배열과 두 번째 배열에 순서대로 입력받습니다.
    // Read the first array, then the second array.
    for (int i = 0; i < 5; i++) cin >> a[i];
    for (int i = 0; i < 5; i++) cin >> b[i];

    // if 문에서 equalArray를 호출하여 교환 전 비교 결과를 출력합니다.
    // Call equalArray in an if statement to print the result before swapping.
    if (equalArray(a, b, 5)) cout << "arrays equal" << "\n";
    else cout << "arrays not equal" << "\n";

    // 두 배열의 원소를 서로 교환합니다.
    // Swap the corresponding elements of the two arrays.
    swapArray(a, b, 5);

    // 교환 후 배열 a를 한 줄로 출력합니다.
    // Print array a on one line after swapping.
    for (int i = 0; i < 5; i++) {
        if (i > 0) cout << " ";
        cout << a[i];
    }
    cout << "\n";

    // 교환 후 배열 b를 한 줄로 출력합니다.
    // Print array b on one line after swapping.
    for (int i = 0; i < 5; i++) {
        if (i > 0) cout << " ";
        cout << b[i];
    }
    cout << "\n";

    return 0;
}

// 같은 위치의 값이 모두 같은지 확인합니다.
// Check whether all corresponding values are equal.
bool equalArray(int* p, int* q, int size) {
    for (int i = 0; i < size; i++) {
        // 다른 값이 발견되면 즉시 false를 반환합니다.
        // Return false immediately when a mismatch is found.
        if (*(p + i) != *(q + i)) return false;
    }
    // 모든 원소를 검사한 뒤 true를 반환합니다.
    // Return true after checking every element.
    return true;
}

// 임시 정수 변수 하나로 두 배열의 원소를 교환합니다.
// Swap the array elements using one temporary integer variable.
void swapArray(int* p, int* q, int size) {
    int temp;
    for (int i = 0; i < size; i++) {
        // 덮어쓰기 전에 첫 번째 값을 보관합니다.
        // Save the first value before overwriting it.
        temp = *(p + i);
        *(p + i) = *(q + i);
        *(q + i) = temp;
    }
}
